(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfs:autoform'] = {};

})();

//# sourceMappingURL=cfs_autoform.js.map
