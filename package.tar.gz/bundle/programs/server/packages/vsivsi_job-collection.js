(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;

/* Package-scope variables */
var Job, JobCollection, __coffeescriptShare;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi:job-collection/job/src/job_class.coffee.js                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var JobQueue, concatReduce, isInteger, methodCall, optionsHelp, reduceCallbacks, splitLongArray, _clearInterval, _setImmediate, _setInterval,     
  __slice = [].slice,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

methodCall = function(root, method, params, cb, after) {
  var name;
  if (after == null) {
    after = (function(ret) {
      return ret;
    });
  }
  name = "" + root + "_" + method;
  if (cb && typeof cb === 'function') {
    return Job._ddp_apply(name, params, (function(_this) {
      return function(err, res) {
        if (err) {
          return cb(err);
        }
        return cb(null, after(res));
      };
    })(this));
  } else {
    return after(Job._ddp_apply(name, params));
  }
};

optionsHelp = function(options, cb) {
  var _ref;
  if ((cb != null) && typeof cb !== 'function') {
    options = cb;
    cb = void 0;
  } else {
    if (!(typeof options === 'object' && options instanceof Array && options.length < 2)) {
      throw new Error('options... in optionsHelp must be an Array with zero or one elements');
    }
    options = (_ref = options != null ? options[0] : void 0) != null ? _ref : {};
  }
  if (typeof options !== 'object') {
    throw new Error('in optionsHelp options not an object or bad callback');
  }
  return [options, cb];
};

splitLongArray = function(arr, max) {
  var i, _i, _ref, _results;
  if (!(arr instanceof Array && max > 0)) {
    throw new Error('splitLongArray: bad params');
  }
  _results = [];
  for (i = _i = 0, _ref = Math.ceil(arr.length / max); 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
    _results.push(arr.slice(i * max, (i + 1) * max));
  }
  return _results;
};

reduceCallbacks = function(cb, num, reduce, init) {
  var cbCount, cbErr, cbRetVal;
  if (reduce == null) {
    reduce = (function(a, b) {
      return a || b;
    });
  }
  if (init == null) {
    init = false;
  }
  if (cb == null) {
    return void 0;
  }
  if (!(typeof cb === 'function' && num > 0 && typeof reduce === 'function')) {
    throw new Error('Bad params given to reduceCallbacks');
  }
  cbRetVal = init;
  cbCount = 0;
  cbErr = null;
  return function(err, res) {
    if (!cbErr) {
      if (err) {
        cbErr = err;
        return cb(err);
      } else {
        cbCount++;
        cbRetVal = reduce(cbRetVal, res);
        if (cbCount === num) {
          return cb(null, cbRetVal);
        } else if (cbCount > num) {
          throw new Error("reduceCallbacks callback invoked more than requested " + num + " times");
        }
      }
    }
  };
};

concatReduce = function(a, b) {
  if (!(a instanceof Array)) {
    a = [a];
  }
  return a.concat(b);
};

isInteger = function(i) {
  return typeof i === 'number' && Math.floor(i) === i;
};

_setImmediate = function() {
  var args, func;
  func = arguments[0], args = 2 <= arguments.length ? __slice.call(arguments, 1) : [];
  if ((typeof Meteor !== "undefined" && Meteor !== null ? Meteor.setTimeout : void 0) != null) {
    return Meteor.setTimeout.apply(Meteor, [func, 0].concat(__slice.call(args)));
  } else if (typeof setImmediate !== "undefined" && setImmediate !== null) {
    return setImmediate.apply(null, [func].concat(__slice.call(args)));
  } else {
    return setTimeout.apply(null, [func, 0].concat(__slice.call(args)));
  }
};

_setInterval = function() {
  var args, func, timeOut;
  func = arguments[0], timeOut = arguments[1], args = 3 <= arguments.length ? __slice.call(arguments, 2) : [];
  if ((typeof Meteor !== "undefined" && Meteor !== null ? Meteor.setInterval : void 0) != null) {
    return Meteor.setInterval.apply(Meteor, [func, timeOut].concat(__slice.call(args)));
  } else {
    return setInterval.apply(null, [func, timeOut].concat(__slice.call(args)));
  }
};

_clearInterval = function(id) {
  if ((typeof Meteor !== "undefined" && Meteor !== null ? Meteor.clearInterval : void 0) != null) {
    return Meteor.clearInterval(id);
  } else {
    return clearInterval(id);
  }
};

JobQueue = (function() {
  function JobQueue() {
    var options, root, type, worker, _i, _ref, _ref1, _ref2, _ref3, _ref4;
    root = arguments[0], type = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), worker = arguments[_i++];
    this.root = root;
    this.type = type;
    this.worker = worker;
    if (!(this instanceof JobQueue)) {
      return (function(func, args, ctor) {
        ctor.prototype = func.prototype;
        var child = new ctor, result = func.apply(child, args);
        return Object(result) === result ? result : child;
      })(JobQueue, [this.root, this.type].concat(__slice.call(options), [this.worker]), function(){});
    }
    _ref = optionsHelp(options, this.worker), options = _ref[0], this.worker = _ref[1];
    this.pollInterval = (_ref1 = options.pollInterval) != null ? _ref1 : 5000;
    this.concurrency = (_ref2 = options.concurrency) != null ? _ref2 : 1;
    this.payload = (_ref3 = options.payload) != null ? _ref3 : 1;
    this.prefetch = (_ref4 = options.prefetch) != null ? _ref4 : 0;
    this._workers = {};
    this._tasks = [];
    this._taskNumber = 0;
    this._stoppingGetWork = void 0;
    this._stoppingTasks = void 0;
    this._interval = null;
    this._getWorkOutstanding = false;
    this.paused = true;
    this.resume();
  }

  JobQueue.prototype._getWork = function() {
    var numJobsToGet;
    numJobsToGet = this.prefetch + this.payload * (this.concurrency - this.running()) - this.length();
    if (numJobsToGet > 0) {
      this._getWorkOutstanding = true;
      return Job.getWork(this.root, this.type, {
        maxJobs: numJobsToGet
      }, (function(_this) {
        return function(err, jobs) {
          var j, _i, _len;
          if (err) {
            return console.error("JobQueue: Received error from getWork(): ", err);
          } else if ((jobs != null) && jobs instanceof Array) {
            if (jobs.length > numJobsToGet) {
              console.error("JobQueue: getWork() returned jobs (" + jobs.length + ") in excess of maxJobs (" + numJobsToGet + ")");
            }
            for (_i = 0, _len = jobs.length; _i < _len; _i++) {
              j = jobs[_i];
              _this._tasks.push(j);
              if (_this._stoppingGetWork == null) {
                _setImmediate(_this._process.bind(_this));
              }
            }
            _this._getWorkOutstanding = false;
            if (_this._stoppingGetWork != null) {
              return _this._stoppingGetWork();
            }
          } else {
            return console.error("JobQueue: Nonarray response from server from getWork()");
          }
        };
      })(this));
    }
  };

  JobQueue.prototype._only_once = function(fn) {
    var called;
    called = false;
    return (function(_this) {
      return function() {
        if (called) {
          console.error("Callback called multiple times in JobQueue");
          throw new Error("Callback was already called.");
        }
        called = true;
        return fn.apply(_this, arguments);
      };
    })(this);
  };

  JobQueue.prototype._process = function() {
    var cb, job, next;
    if (!this.paused && this.running() < this.concurrency && this.length()) {
      if (this.payload > 1) {
        job = this._tasks.splice(0, this.payload);
      } else {
        job = this._tasks.shift();
      }
      job._taskId = "Task_" + (this._taskNumber++);
      this._workers[job._taskId] = job;
      next = (function(_this) {
        return function() {
          delete _this._workers[job._taskId];
          if ((_this._stoppingTasks != null) && _this.running() === 0 && _this.length() === 0) {
            return _this._stoppingTasks();
          } else {
            _setImmediate(_this._process.bind(_this));
            return _setImmediate(_this._getWork.bind(_this));
          }
        };
      })(this);
      cb = this._only_once(next);
      return this.worker(job, cb);
    }
  };

  JobQueue.prototype._stopGetWork = function(callback) {
    _clearInterval(this._interval);
    if (this._getWorkOutstanding) {
      return this._stoppingGetWork = callback;
    } else {
      return _setImmediate(callback);
    }
  };

  JobQueue.prototype._waitForTasks = function(callback) {
    if (this.running() !== 0) {
      return this._stoppingTasks = callback;
    } else {
      return _setImmediate(callback);
    }
  };

  JobQueue.prototype._failJobs = function(tasks, callback) {
    var count, job, _i, _len, _results;
    if (tasks.length === 0) {
      _setImmediate(callback);
    }
    count = 0;
    _results = [];
    for (_i = 0, _len = tasks.length; _i < _len; _i++) {
      job = tasks[_i];
      _results.push(job.fail("Worker shutdown", (function(_this) {
        return function(err, res) {
          count++;
          if (count === tasks.length) {
            return callback();
          }
        };
      })(this)));
    }
    return _results;
  };

  JobQueue.prototype._hard = function(callback) {
    this.paused = true;
    return this._stopGetWork((function(_this) {
      return function() {
        var i, r, tasks, _ref;
        tasks = _this._tasks;
        _this._tasks = [];
        _ref = _this._workers;
        for (i in _ref) {
          r = _ref[i];
          tasks = tasks.concat(r);
        }
        return _this._failJobs(tasks, callback);
      };
    })(this));
  };

  JobQueue.prototype._stop = function(callback) {
    this.paused = true;
    return this._stopGetWork((function(_this) {
      return function() {
        var tasks;
        tasks = _this._tasks;
        _this._tasks = [];
        return _this._waitForTasks(function() {
          return _this._failJobs(tasks, callback);
        });
      };
    })(this));
  };

  JobQueue.prototype._soft = function(callback) {
    return this._stopGetWork((function(_this) {
      return function() {
        return _this._waitForTasks(callback);
      };
    })(this));
  };

  JobQueue.prototype.length = function() {
    return this._tasks.length;
  };

  JobQueue.prototype.running = function() {
    return Object.keys(this._workers).length;
  };

  JobQueue.prototype.idle = function() {
    return this.length() + this.running() === 0;
  };

  JobQueue.prototype.full = function() {
    return this.running() === this.concurrency;
  };

  JobQueue.prototype.pause = function() {
    if (this.paused) {
      return;
    }
    _clearInterval(this._interval);
    this.paused = true;
    return this;
  };

  JobQueue.prototype.resume = function() {
    var w, _i, _ref;
    if (!this.paused) {
      return;
    }
    this.paused = false;
    _setImmediate(this._getWork.bind(this));
    this._interval = _setInterval(this._getWork.bind(this), this.pollInterval);
    for (w = _i = 1, _ref = this.concurrency; 1 <= _ref ? _i <= _ref : _i >= _ref; w = 1 <= _ref ? ++_i : --_i) {
      _setImmediate(this._process.bind(this));
    }
    return this;
  };

  JobQueue.prototype.trigger = function() {
    _setImmediate(this._getWork.bind(this));
    return this;
  };

  JobQueue.prototype.shutdown = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.level == null) {
      options.level = 'normal';
    }
    if (options.quiet == null) {
      options.quiet = false;
    }
    if (cb == null) {
      if (!options.quiet) {
        console.warn("using default shutdown callback!");
      }
      cb = (function(_this) {
        return function() {
          return console.warn("Shutdown complete");
        };
      })(this);
    }
    switch (options.level) {
      case 'hard':
        if (!options.quiet) {
          console.warn("Shutting down hard");
        }
        return this._hard(cb);
      case 'soft':
        if (!options.quiet) {
          console.warn("Shutting down soft");
        }
        return this._soft(cb);
      default:
        if (!options.quiet) {
          console.warn("Shutting down normally");
        }
        return this._stop(cb);
    }
  };

  return JobQueue;

})();

Job = (function() {
  Job.forever = 9007199254740992;

  Job.foreverDate = new Date(8640000000000000);

  Job.jobPriorities = {
    low: 10,
    normal: 0,
    medium: -5,
    high: -10,
    critical: -15
  };

  Job.jobRetryBackoffMethods = ['constant', 'exponential'];

  Job.jobStatuses = ['waiting', 'paused', 'ready', 'running', 'failed', 'cancelled', 'completed'];

  Job.jobLogLevels = ['info', 'success', 'warning', 'danger'];

  Job.jobStatusCancellable = ['running', 'ready', 'waiting', 'paused'];

  Job.jobStatusPausable = ['ready', 'waiting'];

  Job.jobStatusRemovable = ['cancelled', 'completed', 'failed'];

  Job.jobStatusRestartable = ['cancelled', 'failed'];

  Job.ddpMethods = ['startJobs', 'stopJobs', 'startJobServer', 'shutdownJobServer', 'jobRemove', 'jobPause', 'jobResume', 'jobCancel', 'jobRestart', 'jobSave', 'jobRerun', 'getWork', 'getJob', 'jobLog', 'jobProgress', 'jobDone', 'jobFail'];

  Job.ddpPermissionLevels = ['admin', 'manager', 'creator', 'worker'];

  Job.ddpMethodPermissions = {
    'startJobs': ['startJobs', 'admin'],
    'stopJobs': ['stopJobs', 'admin'],
    'startJobServer': ['startJobServer', 'admin'],
    'shutdownJobServer': ['shutdownJobServer', 'admin'],
    'jobRemove': ['jobRemove', 'admin', 'manager'],
    'jobPause': ['jobPause', 'admin', 'manager'],
    'jobResume': ['jobResume', 'admin', 'manager'],
    'jobCancel': ['jobCancel', 'admin', 'manager'],
    'jobRestart': ['jobRestart', 'admin', 'manager'],
    'jobSave': ['jobSave', 'admin', 'creator'],
    'jobRerun': ['jobRerun', 'admin', 'creator'],
    'getWork': ['getWork', 'admin', 'worker'],
    'getJob': ['getJob', 'admin', 'worker'],
    'jobLog': ['jobLog', 'admin', 'worker'],
    'jobProgress': ['jobProgress', 'admin', 'worker'],
    'jobDone': ['jobDone', 'admin', 'worker'],
    'jobFail': ['jobFail', 'admin', 'worker']
  };

  Job._ddp_apply = void 0;

  Job._setDDPApply = function(apply) {
    if (typeof apply === 'function') {
      return this._ddp_apply = apply;
    } else {
      throw new Error("Bad function in Job.setDDPApply()");
    }
  };

  Job.setDDP = function(ddp, Fiber) {
    if (ddp == null) {
      ddp = null;
    }
    if (Fiber == null) {
      Fiber = null;
    }
    if ((ddp != null) && (ddp.call != null) && (ddp.close != null) && (ddp.subscribe != null)) {
      if (ddp.observe != null) {
        if (Fiber != null) {
          return this._setDDPApply(function(name, params, cb) {
            var fib;
            fib = Fiber.current;
            ddp.call(name, params, function(err, res) {
              if ((cb != null) && typeof cb === 'function') {
                return cb(err, res);
              } else {
                if (err) {
                  return fib.throwInto(err);
                } else {
                  return fib.run(res);
                }
              }
            });
            if ((cb != null) && typeof cb === 'function') {

            } else {
              return Fiber["yield"]();
            }
          });
        } else {
          return this._setDDPApply(ddp.call.bind(ddp));
        }
      } else {
        return this._setDDPApply(ddp.apply.bind(ddp));
      }
    } else if (ddp === null && ((typeof Meteor !== "undefined" && Meteor !== null ? Meteor.apply : void 0) != null)) {
      return this._setDDPApply(Meteor.apply);
    } else {
      throw new Error("Bad ddp object in Job.setDDP()");
    }
  };

  Job.getWork = function() {
    var cb, options, root, type, _i, _ref;
    root = arguments[0], type = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (typeof type === 'string') {
      type = [type];
    }
    return methodCall(root, "getWork", [type, options], cb, (function(_this) {
      return function(res) {
        var doc, jobs;
        jobs = ((function() {
          var _j, _len, _results;
          _results = [];
          for (_j = 0, _len = res.length; _j < _len; _j++) {
            doc = res[_j];
            _results.push(new Job(root, doc));
          }
          return _results;
        })()) || [];
        if (options.maxJobs != null) {
          return jobs;
        } else {
          return jobs[0];
        }
      };
    })(this));
  };

  Job.processJobs = JobQueue;

  Job.makeJob = (function() {
    var depFlag;
    depFlag = false;
    return function(root, doc) {
      if (!depFlag) {
        depFlag = true;
        console.warn("Job.makeJob(root, jobDoc) has been deprecated and will be removed in a future release, use 'new Job(root, jobDoc)' instead.");
      }
      return new Job(root, doc);
    };
  })();

  Job.getJob = function() {
    var cb, id, options, root, _i, _ref;
    root = arguments[0], id = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.getLog == null) {
      options.getLog = false;
    }
    return methodCall(root, "getJob", [id, options], cb, (function(_this) {
      return function(doc) {
        if (doc) {
          return new Job(root, doc);
        } else {
          return void 0;
        }
      };
    })(this));
  };

  Job.getJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.getLog == null) {
      options.getLog = false;
    }
    retVal = [];
    chunksOfIds = splitLongArray(ids, 32);
    myCb = reduceCallbacks(cb, chunksOfIds.length, concatReduce, []);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal = retVal.concat(methodCall(root, "getJob", [chunkOfIds, options], myCb, (function(_this) {
        return function(doc) {
          var d, _k, _len1, _results;
          if (doc) {
            _results = [];
            for (_k = 0, _len1 = doc.length; _k < _len1; _k++) {
              d = doc[_k];
              _results.push(new Job(root, d.type, d.data, d));
            }
            return _results;
          } else {
            return null;
          }
        };
      })(this)));
    }
    return retVal;
  };

  Job.pauseJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    retVal = false;
    chunksOfIds = splitLongArray(ids, 256);
    myCb = reduceCallbacks(cb, chunksOfIds.length);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal || (retVal = methodCall(root, "jobPause", [chunkOfIds, options], myCb));
    }
    return retVal;
  };

  Job.resumeJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    retVal = false;
    chunksOfIds = splitLongArray(ids, 256);
    myCb = reduceCallbacks(cb, chunksOfIds.length);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal || (retVal = methodCall(root, "jobResume", [chunkOfIds, options], myCb));
    }
    return retVal;
  };

  Job.cancelJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.antecedents == null) {
      options.antecedents = true;
    }
    retVal = false;
    chunksOfIds = splitLongArray(ids, 256);
    myCb = reduceCallbacks(cb, chunksOfIds.length);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal || (retVal = methodCall(root, "jobCancel", [chunkOfIds, options], myCb));
    }
    return retVal;
  };

  Job.restartJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.retries == null) {
      options.retries = 1;
    }
    if (options.dependents == null) {
      options.dependents = true;
    }
    retVal = false;
    chunksOfIds = splitLongArray(ids, 256);
    myCb = reduceCallbacks(cb, chunksOfIds.length);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal || (retVal = methodCall(root, "jobRestart", [chunkOfIds, options], myCb));
    }
    return retVal;
  };

  Job.removeJobs = function() {
    var cb, chunkOfIds, chunksOfIds, ids, myCb, options, retVal, root, _i, _j, _len, _ref;
    root = arguments[0], ids = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    retVal = false;
    chunksOfIds = splitLongArray(ids, 256);
    myCb = reduceCallbacks(cb, chunksOfIds.length);
    for (_j = 0, _len = chunksOfIds.length; _j < _len; _j++) {
      chunkOfIds = chunksOfIds[_j];
      retVal || (retVal = methodCall(root, "jobRemove", [chunkOfIds, options], myCb));
    }
    return retVal;
  };

  Job.startJobs = function() {
    var cb, options, root, _i, _ref;
    root = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    return methodCall(root, "startJobs", [options], cb);
  };

  Job.stopJobs = function() {
    var cb, options, root, _i, _ref;
    root = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.timeout == null) {
      options.timeout = 60 * 1000;
    }
    return methodCall(root, "stopJobs", [options], cb);
  };

  Job.startJobServer = function() {
    var cb, options, root, _i, _ref;
    root = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    return methodCall(root, "startJobServer", [options], cb);
  };

  Job.shutdownJobServer = function() {
    var cb, options, root, _i, _ref;
    root = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.timeout == null) {
      options.timeout = 60 * 1000;
    }
    return methodCall(root, "shutdownJobServer", [options], cb);
  };

  function Job(root, type, data) {
    var doc, time, _ref;
    this.root = root;
    if (!(this instanceof Job)) {
      return new Job(this.root, type, data);
    }
    if ((((_ref = this.root) != null ? _ref.root : void 0) != null) && typeof this.root.root === 'string') {
      this.root = this.root.root;
    }
    if ((data == null) && ((type != null ? type.data : void 0) != null) && ((type != null ? type.type : void 0) != null)) {
      if (type instanceof Job) {
        console.warn("new Job: job document is a job object!");
        return type;
      }
      doc = type;
      data = doc.data;
      type = doc.type;
    } else {
      doc = {};
    }
    if (!(typeof doc === 'object' && typeof data === 'object' && typeof type === 'string' && typeof this.root === 'string')) {
      throw new Error("new Job: bad parameter(s), " + this.root + " (" + (typeof this.root) + "), " + type + " (" + (typeof type) + "), " + data + " (" + (typeof data) + "), " + doc + " (" + (typeof doc) + ")");
    } else if ((doc.type != null) && (doc.data != null)) {
      this._doc = doc;
    } else {
      time = new Date();
      this._doc = {
        runId: null,
        type: type,
        data: data,
        status: 'waiting',
        updated: time,
        created: time
      };
      this.priority().retry().repeat().after().progress().depends().log("Constructed");
    }
    return this;
  }

  Job.prototype._echo = function(message, level) {
    if (level == null) {
      level = null;
    }
    switch (level) {
      case 'danger':
        console.error(message);
        break;
      case 'warning':
        console.warn(message);
        break;
      case 'success':
        console.log(message);
        break;
      default:
        console.info(message);
    }
  };

  Job.prototype.depends = function(jobs) {
    var depends, j, _i, _len;
    if (jobs) {
      if (jobs instanceof Job) {
        jobs = [jobs];
      }
      if (jobs instanceof Array) {
        depends = this._doc.depends;
        for (_i = 0, _len = jobs.length; _i < _len; _i++) {
          j = jobs[_i];
          if (!(j instanceof Job && (j._doc._id != null))) {
            throw new Error('Each provided object must be a saved Job instance (with an _id)');
          }
          depends.push(j._doc._id);
        }
      } else {
        throw new Error('Bad input parameter: depends() accepts a falsy value, or Job or array of Jobs');
      }
    } else {
      depends = [];
    }
    this._doc.depends = depends;
    this._doc.resolved = [];
    return this;
  };

  Job.prototype.priority = function(level) {
    var priority;
    if (level == null) {
      level = 0;
    }
    if (typeof level === 'string') {
      priority = Job.jobPriorities[level];
      if (priority == null) {
        throw new Error('Invalid string priority level provided');
      }
    } else if (isInteger(level)) {
      priority = level;
    } else {
      throw new Error('priority must be an integer or valid priority level');
      priority = 0;
    }
    this._doc.priority = priority;
    return this;
  };

  Job.prototype.retry = function(options) {
    var _base, _ref;
    if (options == null) {
      options = 0;
    }
    if (isInteger(options) && options >= 0) {
      options = {
        retries: options
      };
    }
    if (typeof options !== 'object') {
      throw new Error('bad parameter: accepts either an integer >= 0 or an options object');
    }
    if (options.retries != null) {
      if (!(isInteger(options.retries) && options.retries >= 0)) {
        throw new Error('bad option: retries must be an integer >= 0');
      }
      options.retries++;
    } else {
      options.retries = Job.forever;
    }
    if (options.until != null) {
      if (!(options.until instanceof Date)) {
        throw new Error('bad option: until must be a Date object');
      }
    } else {
      options.until = Job.foreverDate;
    }
    if (options.wait != null) {
      if (!(isInteger(options.wait) && options.wait >= 0)) {
        throw new Error('bad option: wait must be an integer >= 0');
      }
    } else {
      options.wait = 5 * 60 * 1000;
    }
    if (options.backoff != null) {
      if (_ref = options.backoff, __indexOf.call(Job.jobRetryBackoffMethods, _ref) < 0) {
        throw new Error('bad option: invalid retry backoff method');
      }
    } else {
      options.backoff = 'constant';
    }
    this._doc.retries = options.retries;
    this._doc.retryWait = options.wait;
    if ((_base = this._doc).retried == null) {
      _base.retried = 0;
    }
    this._doc.retryBackoff = options.backoff;
    this._doc.retryUntil = options.until;
    return this;
  };

  Job.prototype.repeat = function(options) {
    var _base;
    if (options == null) {
      options = 0;
    }
    if (isInteger(options) && options >= 0) {
      options = {
        repeats: options
      };
    }
    if (typeof options !== 'object') {
      throw new Error('bad parameter: accepts either an integer >= 0 or an options object');
    }
    if (options.repeats != null) {
      if (!(isInteger(options.repeats) && options.repeats >= 0)) {
        throw new Error('bad option: repeats must be an integer >= 0');
      }
    } else {
      options.repeats = Job.forever;
    }
    if (options.until != null) {
      if (!(options.until instanceof Date)) {
        throw new Error('bad option: until must be a Date object');
      }
    } else {
      options.until = Job.foreverDate;
    }
    if (options.wait != null) {
      if (!(isInteger(options.wait) && options.wait >= 0)) {
        throw new Error('bad option: wait must be an integer >= 0');
      }
    } else {
      options.wait = 5 * 60 * 1000;
    }
    this._doc.repeats = options.repeats;
    this._doc.repeatWait = options.wait;
    if ((_base = this._doc).repeated == null) {
      _base.repeated = 0;
    }
    this._doc.repeatUntil = options.until;
    return this;
  };

  Job.prototype.delay = function(wait) {
    if (wait == null) {
      wait = 0;
    }
    if (!(isInteger(wait) && wait >= 0)) {
      throw new Error('Bad parameter, delay requires a non-negative integer.');
    }
    return this.after(new Date(new Date().valueOf() + wait));
  };

  Job.prototype.after = function(time) {
    var after;
    if (time == null) {
      time = new Date(0);
    }
    if (typeof time === 'object' && time instanceof Date) {
      after = time;
    } else {
      throw new Error('Bad parameter, after requires a valid Date object');
    }
    this._doc.after = after;
    return this;
  };

  Job.prototype.log = function() {
    var cb, message, options, _base, _i, _ref, _ref1;
    message = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.level == null) {
      options.level = 'info';
    }
    if (typeof message !== 'string') {
      throw new Error('Log message must be a string');
    }
    if (!(typeof options.level === 'string' && (_ref1 = options.level, __indexOf.call(Job.jobLogLevels, _ref1) >= 0))) {
      throw new Error('Log level options must be one of Job.jobLogLevels');
    }
    if (options.echo != null) {
      if (options.echo && Job.jobLogLevels.indexOf(options.level) >= Job.jobLogLevels.indexOf(options.echo)) {
        this._echo("LOG: " + options.level + ", " + this._doc._id + " " + this._doc.runId + ": " + message, options.level);
      }
      delete options.echo;
    }
    if (this._doc._id != null) {
      return methodCall(this.root, "jobLog", [this._doc._id, this._doc.runId, message, options], cb);
    } else {
      if ((_base = this._doc).log == null) {
        _base.log = [];
      }
      this._doc.log.push({
        time: new Date(),
        runId: null,
        level: options.level,
        message: message
      });
      if ((cb != null) && typeof cb === 'function') {
        _setImmediate(cb, null, true);
      }
      return this;
    }
  };

  Job.prototype.progress = function() {
    var cb, completed, options, progress, total, _i, _ref;
    completed = arguments[0], total = arguments[1], options = 4 <= arguments.length ? __slice.call(arguments, 2, _i = arguments.length - 1) : (_i = 2, []), cb = arguments[_i++];
    if (completed == null) {
      completed = 0;
    }
    if (total == null) {
      total = 1;
    }
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (typeof completed === 'number' && typeof total === 'number' && completed >= 0 && total > 0 && total >= completed) {
      progress = {
        completed: completed,
        total: total,
        percent: 100 * completed / total
      };
      if (options.echo) {
        delete options.echo;
        this._echo("PROGRESS: " + this._doc._id + " " + this._doc.runId + ": " + progress.completed + " out of " + progress.total + " (" + progress.percent + "%)");
      }
      if ((this._doc._id != null) && (this._doc.runId != null)) {
        return methodCall(this.root, "jobProgress", [this._doc._id, this._doc.runId, completed, total, options], cb, (function(_this) {
          return function(res) {
            if (res) {
              _this._doc.progress = progress;
            }
            return res;
          };
        })(this));
      } else if (this._doc._id == null) {
        this._doc.progress = progress;
        if ((cb != null) && typeof cb === 'function') {
          _setImmediate(cb, null, true);
        }
        return this;
      }
    } else {
      throw new Error("job.progress: something is wrong with progress params: " + this.id + ", " + completed + " out of " + total);
    }
    return null;
  };

  Job.prototype.save = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    return methodCall(this.root, "jobSave", [this._doc, options], cb, (function(_this) {
      return function(id) {
        if (id) {
          _this._doc._id = id;
        }
        return id;
      };
    })(this));
  };

  Job.prototype.refresh = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.getLog == null) {
      options.getLog = false;
    }
    if (this._doc._id != null) {
      return methodCall(this.root, "getJob", [this._doc._id, options], cb, (function(_this) {
        return function(doc) {
          if (doc != null) {
            _this._doc = doc;
            return _this;
          } else {
            return false;
          }
        };
      })(this));
    } else {
      throw new Error("Can't call .refresh() on an unsaved job");
    }
  };

  Job.prototype.done = function() {
    var cb, options, result, _i, _ref;
    result = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    if (result == null) {
      result = {};
    }
    if (typeof result === 'function') {
      cb = result;
      result = {};
    }
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (!((result != null) && typeof result === 'object')) {
      result = {
        value: result
      };
    }
    if ((this._doc._id != null) && (this._doc.runId != null)) {
      return methodCall(this.root, "jobDone", [this._doc._id, this._doc.runId, result, options], cb);
    } else {
      throw new Error("Can't call .done() on an unsaved or non-running job");
    }
    return null;
  };

  Job.prototype.fail = function() {
    var cb, options, result, _i, _ref;
    result = arguments[0], options = 3 <= arguments.length ? __slice.call(arguments, 1, _i = arguments.length - 1) : (_i = 1, []), cb = arguments[_i++];
    if (result == null) {
      result = "No error information provided";
    }
    if (typeof result === 'function') {
      cb = result;
      result = "No error information provided";
    }
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (!((result != null) && typeof result === 'object')) {
      result = {
        value: result
      };
    }
    if (options.fatal == null) {
      options.fatal = false;
    }
    if ((this._doc._id != null) && (this._doc.runId != null)) {
      return methodCall(this.root, "jobFail", [this._doc._id, this._doc.runId, result, options], cb);
    } else {
      throw new Error("Can't call .fail() on an unsaved or non-running job");
    }
    return null;
  };

  Job.prototype.pause = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (this._doc._id != null) {
      return methodCall(this.root, "jobPause", [this._doc._id, options], cb);
    } else {
      this._doc.status = 'paused';
      if ((cb != null) && typeof cb === 'function') {
        _setImmediate(cb, null, true);
      }
      return this;
    }
    return null;
  };

  Job.prototype.resume = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (this._doc._id != null) {
      return methodCall(this.root, "jobResume", [this._doc._id, options], cb);
    } else {
      this._doc.status = 'waiting';
      if ((cb != null) && typeof cb === 'function') {
        _setImmediate(cb, null, true);
      }
      return this;
    }
    return null;
  };

  Job.prototype.cancel = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.antecedents == null) {
      options.antecedents = true;
    }
    if (this._doc._id != null) {
      return methodCall(this.root, "jobCancel", [this._doc._id, options], cb);
    } else {
      throw new Error("Can't call .cancel() on an unsaved job");
    }
    return null;
  };

  Job.prototype.restart = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.retries == null) {
      options.retries = 1;
    }
    if (options.dependents == null) {
      options.dependents = true;
    }
    if (this._doc._id != null) {
      return methodCall(this.root, "jobRestart", [this._doc._id, options], cb);
    } else {
      throw new Error("Can't call .restart() on an unsaved job");
    }
    return null;
  };

  Job.prototype.rerun = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (options.repeats == null) {
      options.repeats = 0;
    }
    if (options.wait == null) {
      options.wait = this._doc.repeatWait;
    }
    if (this._doc._id != null) {
      return methodCall(this.root, "jobRerun", [this._doc._id, options], cb);
    } else {
      throw new Error("Can't call .rerun() on an unsaved job");
    }
    return null;
  };

  Job.prototype.remove = function() {
    var cb, options, _i, _ref;
    options = 2 <= arguments.length ? __slice.call(arguments, 0, _i = arguments.length - 1) : (_i = 0, []), cb = arguments[_i++];
    _ref = optionsHelp(options, cb), options = _ref[0], cb = _ref[1];
    if (this._doc._id != null) {
      return methodCall(this.root, "jobRemove", [this._doc._id, options], cb);
    } else {
      throw new Error("Can't call .remove() on an unsaved job");
    }
    return null;
  };

  Object.defineProperties(Job.prototype, {
    doc: {
      get: function() {
        return this._doc;
      },
      set: function() {
        return console.warn("Job.doc cannot be directly assigned.");
      }
    },
    type: {
      get: function() {
        return this._doc.type;
      },
      set: function() {
        return console.warn("Job.type cannot be directly assigned.");
      }
    },
    data: {
      get: function() {
        return this._doc.data;
      },
      set: function() {
        return console.warn("Job.data cannot be directly assigned.");
      }
    }
  });

  return Job;

})();

if ((typeof module !== "undefined" && module !== null ? module.exports : void 0) != null) {
  module.exports = Job;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi:job-collection/shared.coffee.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var JobCollectionBase, _validId, _validIntGTEOne, _validIntGTEZero, _validJobDoc, _validLog, _validLogLevel, _validNumGTEOne, _validNumGTEZero, _validNumGTZero, _validProgress, _validRetryBackoff, _validStatus,
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  __slice = [].slice;

_validNumGTEZero = function(v) {
  return Match.test(v, Number) && v >= 0.0;
};

_validNumGTZero = function(v) {
  return Match.test(v, Number) && v > 0.0;
};

_validNumGTEOne = function(v) {
  return Match.test(v, Number) && v >= 1.0;
};

_validIntGTEZero = function(v) {
  return _validNumGTEZero(v) && Math.floor(v) === v;
};

_validIntGTEOne = function(v) {
  return _validNumGTEOne(v) && Math.floor(v) === v;
};

_validStatus = function(v) {
  return Match.test(v, String) && __indexOf.call(Job.jobStatuses, v) >= 0;
};

_validLogLevel = function(v) {
  return Match.test(v, String) && __indexOf.call(Job.jobLogLevels, v) >= 0;
};

_validRetryBackoff = function(v) {
  return Match.test(v, String) && __indexOf.call(Job.jobRetryBackoffMethods, v) >= 0;
};

_validId = function(v) {
  return Match.test(v, Match.OneOf(String, Mongo.Collection.ObjectID));
};

_validLog = function() {
  return [
    {
      time: Date,
      runId: Match.OneOf(Match.Where(_validId), null),
      level: Match.Where(_validLogLevel),
      message: String,
      data: Match.Optional(Object)
    }
  ];
};

_validProgress = function() {
  return {
    completed: Match.Where(_validNumGTEZero),
    total: Match.Where(_validNumGTEZero),
    percent: Match.Where(_validNumGTEZero)
  };
};

_validJobDoc = function() {
  return {
    _id: Match.Optional(Match.OneOf(Match.Where(_validId), null)),
    runId: Match.OneOf(Match.Where(_validId), null),
    type: String,
    status: Match.Where(_validStatus),
    data: Object,
    result: Match.Optional(Object),
    failures: Match.Optional([Object]),
    priority: Match.Integer,
    depends: [Match.Where(_validId)],
    resolved: [Match.Where(_validId)],
    after: Date,
    updated: Date,
    log: Match.Optional(_validLog()),
    progress: _validProgress(),
    retries: Match.Where(_validIntGTEZero),
    retried: Match.Where(_validIntGTEZero),
    retryUntil: Date,
    retryWait: Match.Where(_validIntGTEZero),
    retryBackoff: Match.Where(_validRetryBackoff),
    repeats: Match.Where(_validIntGTEZero),
    repeated: Match.Where(_validIntGTEZero),
    repeatUntil: Date,
    repeatWait: Match.Where(_validIntGTEZero),
    created: Date
  };
};

JobCollectionBase = (function(_super) {
  var _createLogEntry, _logMessage;

  __extends(JobCollectionBase, _super);

  function JobCollectionBase(root, options) {
    var collectionName;
    this.root = root != null ? root : 'queue';
    if (options == null) {
      options = {};
    }
    if (!(this instanceof JobCollectionBase)) {
      return new JobCollectionBase(this.root, options);
    }
    if (!(this instanceof Mongo.Collection)) {
      throw new Error('The global definition of Mongo.Collection has changed since the job-collection package was loaded. Please ensure that any packages that redefine Mongo.Collection are loaded before job-collection.');
    }
    if (options.noCollectionSuffix == null) {
      options.noCollectionSuffix = false;
    }
    collectionName = this.root;
    if (!options.noCollectionSuffix) {
      collectionName += '.jobs';
    }
    delete options.noCollectionSuffix;
    Job.setDDP(options.connection);
    JobCollectionBase.__super__.constructor.call(this, collectionName, options);
  }

  JobCollectionBase.prototype._validNumGTEZero = _validNumGTEZero;

  JobCollectionBase.prototype._validNumGTZero = _validNumGTZero;

  JobCollectionBase.prototype._validNumGTEOne = _validNumGTEOne;

  JobCollectionBase.prototype._validIntGTEZero = _validIntGTEZero;

  JobCollectionBase.prototype._validIntGTEOne = _validIntGTEOne;

  JobCollectionBase.prototype._validStatus = _validStatus;

  JobCollectionBase.prototype._validLogLevel = _validLogLevel;

  JobCollectionBase.prototype._validRetryBackoff = _validRetryBackoff;

  JobCollectionBase.prototype._validId = _validId;

  JobCollectionBase.prototype._validLog = _validLog;

  JobCollectionBase.prototype._validProgress = _validProgress;

  JobCollectionBase.prototype._validJobDoc = _validJobDoc;

  JobCollectionBase.prototype.jobLogLevels = Job.jobLogLevels;

  JobCollectionBase.prototype.jobPriorities = Job.jobPriorities;

  JobCollectionBase.prototype.jobStatuses = Job.jobPriorities;

  JobCollectionBase.prototype.jobStatusCancellable = Job.jobStatusCancellable;

  JobCollectionBase.prototype.jobStatusPausable = Job.jobStatusPausable;

  JobCollectionBase.prototype.jobStatusRemovable = Job.jobStatusRemovable;

  JobCollectionBase.prototype.jobStatusRestartable = Job.jobStatusRestartable;

  JobCollectionBase.prototype.forever = Job.forever;

  JobCollectionBase.prototype.foreverDate = Job.foreverDate;

  JobCollectionBase.prototype.ddpMethods = Job.ddpMethods;

  JobCollectionBase.prototype.ddpPermissionLevels = Job.ddpPermissionLevels;

  JobCollectionBase.prototype.ddpMethodPermissions = Job.ddpMethodPermissions;

  JobCollectionBase.prototype.processJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return (function(func, args, ctor) {
      ctor.prototype = func.prototype;
      var child = new ctor, result = func.apply(child, args);
      return Object(result) === result ? result : child;
    })(Job.processJobs, [this.root].concat(__slice.call(params)), function(){});
  };

  JobCollectionBase.prototype.getJob = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.getJob.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.getWork = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.getWork.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.getJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.getJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.cancelJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.cancelJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.pauseJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.pauseJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.resumeJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.resumeJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.restartJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.restartJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.removeJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.removeJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.setDDP = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.setDDP.apply(Job, params);
  };

  JobCollectionBase.prototype.startJobServer = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.startJobServer.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.shutdownJobServer = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.shutdownJobServer.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.startJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.startJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.stopJobs = function() {
    var params;
    params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    return Job.stopJobs.apply(Job, [this.root].concat(__slice.call(params)));
  };

  JobCollectionBase.prototype.jobDocPattern = _validJobDoc();

  JobCollectionBase.prototype.makeJob = (function() {
    var dep;
    dep = false;
    return function() {
      var params;
      params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
      if (!dep) {
        dep = true;
        console.warn("WARNING: jc.makeJob() has been deprecated. Use new Job(jc, doc) instead.");
      }
      return (function(func, args, ctor) {
        ctor.prototype = func.prototype;
        var child = new ctor, result = func.apply(child, args);
        return Object(result) === result ? result : child;
      })(Job, [this.root].concat(__slice.call(params)), function(){});
    };
  })();

  JobCollectionBase.prototype.createJob = (function() {
    var dep;
    dep = false;
    return function() {
      var params;
      params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
      if (!dep) {
        dep = true;
        console.warn("WARNING: jc.createJob() has been deprecated. Use new Job(jc, type, data) instead.");
      }
      return (function(func, args, ctor) {
        ctor.prototype = func.prototype;
        var child = new ctor, result = func.apply(child, args);
        return Object(result) === result ? result : child;
      })(Job, [this.root].concat(__slice.call(params)), function(){});
    };
  })();

  _createLogEntry = function(message, runId, level, time) {
    var l;
    if (message == null) {
      message = '';
    }
    if (runId == null) {
      runId = null;
    }
    if (level == null) {
      level = 'info';
    }
    if (time == null) {
      time = new Date();
    }
    l = {
      time: time,
      runId: runId,
      message: message,
      level: level
    };
    return l;
  };

  _logMessage = {
    'rerun': function(id, runId) {
      return _createLogEntry("Rerunning job " + id + " from run " + runId);
    },
    'running': function(runId) {
      return _createLogEntry("Job Running", runId);
    },
    'paused': function() {
      return _createLogEntry("Job Paused");
    },
    'resumed': function() {
      return _createLogEntry("Job Resumed");
    },
    'cancelled': function() {
      return _createLogEntry("Job Cancelled", null, 'warn');
    },
    'restarted': function() {
      return _createLogEntry("Job Restarted");
    },
    'resubmitted': function() {
      return _createLogEntry("Job Resubmitted");
    },
    'submitted': function() {
      return _createLogEntry("Job Submitted");
    },
    'completed': function(runId) {
      return _createLogEntry("Job Completed Successfully", runId);
    },
    'resolved': function(id, runId) {
      return _createLogEntry("Dependency resolved for " + id + " by " + runId, runId);
    },
    'failed': function(runId, fatal, value) {
      var level, msg;
      msg = "Job Failed with" + (fatal ? ' Fatal' : '') + " Error" + ((value != null) && typeof value === 'string' ? ': ' + value : '') + ".";
      level = fatal ? 'danger' : 'warning';
      return _createLogEntry(msg, runId, level);
    }
  };

  JobCollectionBase.prototype._methodWrapper = function(method, func) {
    var toLog;
    toLog = this._toLog;
    return function() {
      var params, retval, user, _ref;
      params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
      user = (_ref = this.userId) != null ? _ref : "[UNAUTHENTICATED]";
      toLog(user, method, "params: " + JSON.stringify(params));
      retval = func.apply(null, params);
      toLog(user, method, "returned: " + JSON.stringify(retval));
      return retval;
    };
  };

  JobCollectionBase.prototype._generateMethods = function() {
    var baseMethodName, methodFunc, methodName, methodPrefix, methodsOut;
    methodsOut = {};
    methodPrefix = '_DDPMethod_';
    for (methodName in this) {
      methodFunc = this[methodName];
      if (!(methodName.slice(0, methodPrefix.length) === methodPrefix)) {
        continue;
      }
      baseMethodName = methodName.slice(methodPrefix.length);
      methodsOut["" + this.root + "_" + baseMethodName] = this._methodWrapper(baseMethodName, methodFunc.bind(this));
    }
    return methodsOut;
  };

  JobCollectionBase.prototype._idsOfDeps = function(ids, antecedents, dependents, jobStatuses) {
    var antsArray, dependsIds, dependsQuery;
    dependsQuery = [];
    if (dependents) {
      dependsQuery.push({
        depends: {
          $elemMatch: {
            $in: ids
          }
        }
      });
    }
    if (antecedents) {
      antsArray = [];
      this.find({
        _id: {
          $in: ids
        }
      }, {
        fields: {
          depends: 1
        },
        transform: null
      }).forEach(function(d) {
        var i, _i, _len, _ref, _results;
        if (__indexOf.call(antsArray, i) < 0) {
          _ref = d.depends;
          _results = [];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            i = _ref[_i];
            _results.push(antsArray.push(i));
          }
          return _results;
        }
      });
      if (antsArray.length > 0) {
        dependsQuery.push({
          _id: {
            $in: antsArray
          }
        });
      }
    }
    if (dependsQuery) {
      dependsIds = [];
      this.find({
        status: {
          $in: jobStatuses
        },
        $or: dependsQuery
      }, {
        fields: {
          _id: 1
        },
        transform: null
      }).forEach(function(d) {
        var _ref;
        if (_ref = d._id, __indexOf.call(dependsIds, _ref) < 0) {
          return dependsIds.push(d._id);
        }
      });
    }
    return dependsIds;
  };

  JobCollectionBase.prototype._rerun_job = function(doc, repeats, wait, repeatUntil) {
    var id, jobId, logObj, runId, time;
    if (repeats == null) {
      repeats = doc.repeats - 1;
    }
    if (wait == null) {
      wait = doc.repeatWait;
    }
    if (repeatUntil == null) {
      repeatUntil = doc.repeatUntil;
    }
    id = doc._id;
    runId = doc.runId;
    time = new Date();
    delete doc._id;
    delete doc.result;
    delete doc.failures;
    doc.runId = null;
    doc.status = "waiting";
    doc.retries = doc.retries + doc.retried;
    if (doc.retries > this.forever) {
      doc.retries = this.forever;
    }
    doc.retryUntil = repeatUntil;
    doc.retried = 0;
    doc.repeats = repeats;
    if (doc.repeats > this.forever) {
      doc.repeats = this.forever;
    }
    doc.repeatUntil = repeatUntil;
    doc.repeated = doc.repeated + 1;
    doc.updated = time;
    doc.created = time;
    doc.progress = {
      completed: 0,
      total: 1,
      percent: 0
    };
    if (logObj = _logMessage.rerun(id, runId)) {
      doc.log = [logObj];
    } else {
      doc.log = [];
    }
    doc.after = new Date(time.valueOf() + wait);
    if (jobId = this.insert(doc)) {
      if (typeof this._promote_jobs === "function") {
        this._promote_jobs([jobId]);
      }
      return jobId;
    } else {
      console.warn("Job rerun/repeat failed to reschedule!", id, runId);
    }
    return null;
  };

  JobCollectionBase.prototype._DDPMethod_startJobServer = function(options) {
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    if (!this.isSimulation) {
      if (this.stopped && this.stopped !== true) {
        Meteor.clearTimeout(this.stopped);
      }
      this.stopped = false;
    }
    return true;
  };

  JobCollectionBase.prototype._DDPMethod_startJobs = (function() {
    var depFlag;
    depFlag = false;
    return function(options) {
      if (!depFlag) {
        depFlag = true;
        console.warn("Deprecation Warning: jc.startJobs() has been renamed to jc.startJobServer()");
      }
      return this._DDPMethod_startJobServer(options);
    };
  })();

  JobCollectionBase.prototype._DDPMethod_shutdownJobServer = function(options) {
    check(options, Match.Optional({
      timeout: Match.Optional(Match.Where(_validIntGTEOne))
    }));
    if (options == null) {
      options = {};
    }
    if (options.timeout == null) {
      options.timeout = 60 * 1000;
    }
    if (!this.isSimulation) {
      if (this.stopped && this.stopped !== true) {
        Meteor.clearTimeout(this.stopped);
      }
      this.stopped = Meteor.setTimeout((function(_this) {
        return function() {
          var cursor, failedJobs;
          cursor = _this.find({
            status: 'running'
          }, {
            transform: null
          });
          failedJobs = cursor.count();
          if (failedJobs !== 0) {
            console.warn("Failing " + failedJobs + " jobs on queue stop.");
          }
          cursor.forEach(function(d) {
            return _this._DDPMethod_jobFail(d._id, d.runId, "Running at Job Server shutdown.");
          });
          if (_this.logStream != null) {
            _this.logStream.end();
            return _this.logStream = null;
          }
        };
      })(this), options.timeout);
    }
    return true;
  };

  JobCollectionBase.prototype._DDPMethod_stopJobs = (function() {
    var depFlag;
    depFlag = false;
    return function(options) {
      if (!depFlag) {
        depFlag = true;
        console.warn("Deprecation Warning: jc.stopJobs() has been renamed to jc.shutdownJobServer()");
      }
      return this._DDPMethod_shutdownJobServer(options);
    };
  })();

  JobCollectionBase.prototype._DDPMethod_getJob = function(ids, options) {
    var d, docs, single;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({
      getLog: Match.Optional(Boolean),
      getFailures: Match.Optional(Boolean)
    }));
    if (options == null) {
      options = {};
    }
    if (options.getLog == null) {
      options.getLog = false;
    }
    if (options.getFailures == null) {
      options.getFailures = false;
    }
    single = false;
    if (_validId(ids)) {
      ids = [ids];
      single = true;
    }
    if (ids.length === 0) {
      return null;
    }
    docs = this.find({
      _id: {
        $in: ids
      }
    }, {
      fields: {
        log: options.getLog ? 1 : 0,
        failures: options.getFailures ? 1 : 0,
        _private: 0
      },
      transform: null
    }).fetch();
    if (docs != null ? docs.length : void 0) {
      if (this.scrub != null) {
        docs = (function() {
          var _i, _len, _results;
          _results = [];
          for (_i = 0, _len = docs.length; _i < _len; _i++) {
            d = docs[_i];
            _results.push(this.scrub(d));
          }
          return _results;
        }).call(this);
      }
      check(docs, [_validJobDoc()]);
      if (single) {
        return docs[0];
      } else {
        return docs;
      }
    }
    return null;
  };

  JobCollectionBase.prototype._DDPMethod_getWork = function(type, options) {
    var d, docs, foundDocs, ids, logObj, mods, num, runId, time;
    check(type, Match.OneOf(String, [String]));
    check(options, Match.Optional({
      maxJobs: Match.Optional(Match.Where(_validIntGTEOne))
    }));
    if (options == null) {
      options = {};
    }
    if (options.maxJobs == null) {
      options.maxJobs = 1;
    }
    if (this.stopped) {
      return [];
    }
    if (typeof type === 'string') {
      type = [type];
    }
    time = new Date();
    docs = [];
    runId = this._makeNewID();
    while (docs.length < options.maxJobs) {
      ids = this.find({
        type: {
          $in: type
        },
        status: 'ready',
        runId: null
      }, {
        sort: {
          priority: 1,
          retryUntil: 1,
          after: 1
        },
        limit: options.maxJobs - docs.length,
        fields: {
          _id: 1
        },
        transform: null
      }).map(function(d) {
        return d._id;
      });
      if (!((ids != null ? ids.length : void 0) > 0)) {
        break;
      }
      mods = {
        $set: {
          status: 'running',
          runId: runId,
          updated: time
        },
        $inc: {
          retries: -1,
          retried: 1
        }
      };
      if (logObj = _logMessage.running(runId)) {
        mods.$push = {
          log: logObj
        };
      }
      num = this.update({
        _id: {
          $in: ids
        },
        status: 'ready',
        runId: null
      }, mods, {
        multi: true
      });
      if (num > 0) {
        foundDocs = this.find({
          _id: {
            $in: ids
          },
          runId: runId
        }, {
          fields: {
            log: 0,
            failures: 0,
            _private: 0
          },
          transform: null
        }).fetch();
        if ((foundDocs != null ? foundDocs.length : void 0) > 0) {
          if (this.scrub != null) {
            foundDocs = (function() {
              var _i, _len, _results;
              _results = [];
              for (_i = 0, _len = foundDocs.length; _i < _len; _i++) {
                d = foundDocs[_i];
                _results.push(this.scrub(d));
              }
              return _results;
            }).call(this);
          }
          check(docs, [_validJobDoc()]);
          docs = docs.concat(foundDocs);
        }
      }
    }
    return docs;
  };

  JobCollectionBase.prototype._DDPMethod_jobRemove = function(ids, options) {
    var num;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    if (_validId(ids)) {
      ids = [ids];
    }
    if (ids.length === 0) {
      return false;
    }
    num = this.remove({
      _id: {
        $in: ids
      },
      status: {
        $in: this.jobStatusRemovable
      }
    });
    if (num > 0) {
      return true;
    } else {
      console.warn("jobRemove failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobPause = function(ids, options) {
    var logObj, mods, num, time;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    if (_validId(ids)) {
      ids = [ids];
    }
    if (ids.length === 0) {
      return false;
    }
    time = new Date();
    mods = {
      $set: {
        status: "paused",
        updated: time
      }
    };
    if (logObj = _logMessage.paused()) {
      mods.$push = {
        log: logObj
      };
    }
    num = this.update({
      _id: {
        $in: ids
      },
      status: {
        $in: this.jobStatusPausable
      }
    }, mods, {
      multi: true
    });
    if (num > 0) {
      return true;
    } else {
      console.warn("jobPause failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobResume = function(ids, options) {
    var logObj, mods, num, time;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    if (_validId(ids)) {
      ids = [ids];
    }
    if (ids.length === 0) {
      return false;
    }
    time = new Date();
    mods = {
      $set: {
        status: "waiting",
        updated: time
      }
    };
    if (logObj = _logMessage.resumed()) {
      mods.$push = {
        log: logObj
      };
    }
    num = this.update({
      _id: {
        $in: ids
      },
      status: "paused",
      updated: {
        $ne: time
      }
    }, mods, {
      multi: true
    });
    if (num > 0) {
      if (typeof this._promote_jobs === "function") {
        this._promote_jobs(ids);
      }
      return true;
    } else {
      console.warn("jobResume failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobCancel = function(ids, options) {
    var cancelIds, depsCancelled, logObj, mods, num, time;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({
      antecedents: Match.Optional(Boolean),
      dependents: Match.Optional(Boolean)
    }));
    if (options == null) {
      options = {};
    }
    if (options.antecedents == null) {
      options.antecedents = false;
    }
    if (options.dependents == null) {
      options.dependents = true;
    }
    if (_validId(ids)) {
      ids = [ids];
    }
    if (ids.length === 0) {
      return false;
    }
    time = new Date();
    mods = {
      $set: {
        status: "cancelled",
        runId: null,
        progress: {
          completed: 0,
          total: 1,
          percent: 0
        },
        updated: time
      }
    };
    if (logObj = _logMessage.cancelled()) {
      mods.$push = {
        log: logObj
      };
    }
    num = this.update({
      _id: {
        $in: ids
      },
      status: {
        $in: this.jobStatusCancellable
      }
    }, mods, {
      multi: true
    });
    cancelIds = this._idsOfDeps(ids, options.antecedents, options.dependents, this.jobStatusCancellable);
    depsCancelled = false;
    if (cancelIds.length > 0) {
      depsCancelled = this._DDPMethod_jobCancel(cancelIds, options);
    }
    if (num > 0 || depsCancelled) {
      return true;
    } else {
      console.warn("jobCancel failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobRestart = function(ids, options) {
    var depsRestarted, logObj, mods, num, query, restartIds, time;
    check(ids, Match.OneOf(Match.Where(_validId), [Match.Where(_validId)]));
    check(options, Match.Optional({
      retries: Match.Optional(Match.Where(_validIntGTEOne)),
      until: Match.Optional(Date),
      antecedents: Match.Optional(Boolean),
      dependents: Match.Optional(Boolean)
    }));
    if (options == null) {
      options = {};
    }
    if (options.retries == null) {
      options.retries = 1;
    }
    if (options.retries > this.forever) {
      options.retries = this.forever;
    }
    if (options.dependents == null) {
      options.dependents = false;
    }
    if (options.antecedents == null) {
      options.antecedents = true;
    }
    if (_validId(ids)) {
      ids = [ids];
    }
    if (ids.length === 0) {
      return false;
    }
    console.log("Restarting: " + ids);
    time = new Date();
    query = {
      _id: {
        $in: ids
      },
      status: {
        $in: this.jobStatusRestartable
      }
    };
    mods = {
      $set: {
        status: "waiting",
        progress: {
          completed: 0,
          total: 1,
          percent: 0
        },
        updated: time
      },
      $inc: {
        retries: options.retries
      }
    };
    if (logObj = _logMessage.restarted()) {
      mods.$push = {
        log: logObj
      };
    }
    if (options.until != null) {
      mods.$set.retryUntil = options.until;
    }
    num = this.update(query, mods, {
      multi: true
    });
    restartIds = this._idsOfDeps(ids, options.antecedents, options.dependents, this.jobStatusRestartable);
    depsRestarted = false;
    if (restartIds.length > 0) {
      depsRestarted = this._DDPMethod_jobRestart(restartIds, options);
    }
    if (num > 0 || depsRestarted) {
      if (typeof this._promote_jobs === "function") {
        this._promote_jobs(ids);
      }
      return true;
    } else {
      console.warn("jobRestart failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobSave = function(doc, options) {
    var logObj, mods, newId, num, time;
    check(doc, _validJobDoc());
    check(options, Match.Optional({
      cancelRepeats: Match.Optional(Boolean)
    }));
    check(doc.status, Match.Where(function(v) {
      return Match.test(v, String) && (v === 'waiting' || v === 'paused');
    }));
    if (options == null) {
      options = {};
    }
    if (options.cancelRepeats == null) {
      options.cancelRepeats = false;
    }
    if (doc.repeats > this.forever) {
      doc.repeats = this.forever;
    }
    if (doc.retries > this.forever) {
      doc.retries = this.forever;
    }
    time = new Date();
    if (doc.after < time) {
      doc.after = time;
    }
    if (doc.retryUntil < time) {
      doc.retryUntil = time;
    }
    if (doc.repeatUntil < time) {
      doc.repeatUntil = time;
    }
    if (doc._id) {
      mods = {
        $set: {
          status: 'waiting',
          data: doc.data,
          retries: doc.retries,
          retryUntil: doc.retryUntil,
          retryWait: doc.retryWait,
          retryBackoff: doc.retryBackoff,
          repeats: doc.repeats,
          repeatUntil: doc.repeatUntil,
          repeatWait: doc.repeatWait,
          depends: doc.depends,
          priority: doc.priority,
          after: doc.after,
          updated: time
        }
      };
      if (logObj = _logMessage.resubmitted()) {
        mods.$push = {
          log: logObj
        };
      }
      num = this.update({
        _id: doc._id,
        status: 'paused',
        runId: null
      }, mods);
      if (num) {
        if (typeof this._promote_jobs === "function") {
          this._promote_jobs([doc._id]);
        }
        return doc._id;
      } else {
        return null;
      }
    } else {
      if (doc.repeats === this.forever && options.cancelRepeats) {
        this.find({
          type: doc.type,
          status: {
            $in: this.jobStatusCancellable
          }
        }, {
          transform: null
        }).forEach((function(_this) {
          return function(d) {
            return _this._DDPMethod_jobCancel(d._id, {});
          };
        })(this));
      }
      doc.created = time;
      doc.log.push(_logMessage.submitted());
      newId = this.insert(doc);
      if (typeof this._promote_jobs === "function") {
        this._promote_jobs([newId]);
      }
      return newId;
    }
  };

  JobCollectionBase.prototype._DDPMethod_jobProgress = function(id, runId, completed, total, options) {
    var num, progress, time;
    check(id, Match.Where(_validId));
    check(runId, Match.Where(_validId));
    check(completed, Match.Where(_validNumGTEZero));
    check(total, Match.Where(_validNumGTZero));
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    if (this.stopped) {
      return null;
    }
    progress = {
      completed: completed,
      total: total,
      percent: 100 * completed / total
    };
    check(progress, Match.Where(function(v) {
      var _ref;
      return v.total >= v.completed && (0 <= (_ref = v.percent) && _ref <= 100);
    }));
    time = new Date();
    console.log("Updating progress", id, runId, progress);
    num = this.update({
      _id: id,
      runId: runId,
      status: "running"
    }, {
      $set: {
        progress: progress,
        updated: time
      }
    });
    if (num === 1) {
      return true;
    } else {
      console.warn("jobProgress failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobLog = function(id, runId, message, options) {
    var logObj, num, time, _ref;
    check(id, Match.Where(_validId));
    check(runId, Match.Where(_validId));
    check(message, String);
    check(options, Match.Optional({
      level: Match.Optional(Match.Where(_validLogLevel)),
      data: Match.Optional(Object)
    }));
    if (options == null) {
      options = {};
    }
    time = new Date();
    logObj = {
      time: time,
      runId: runId,
      level: (_ref = options.level) != null ? _ref : 'info',
      message: message
    };
    if (options.data != null) {
      logObj.data = options.data;
    }
    num = this.update({
      _id: id
    }, {
      $push: {
        log: logObj
      },
      $set: {
        updated: time
      }
    });
    if (num === 1) {
      return true;
    } else {
      console.warn("jobLog failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobRerun = function(id, options) {
    var doc;
    check(id, Match.Where(_validId));
    check(options, Match.Optional({
      repeats: Match.Optional(Match.Where(_validIntGTEZero)),
      until: Match.Optional(Date),
      wait: Match.Optional(Match.Where(_validIntGTEZero))
    }));
    doc = this.findOne({
      _id: id,
      status: "completed"
    }, {
      fields: {
        result: 0,
        failures: 0,
        log: 0,
        progress: 0,
        updated: 0,
        after: 0,
        status: 0
      },
      transform: null
    });
    if (doc != null) {
      if (options == null) {
        options = {};
      }
      if (options.repeats == null) {
        options.repeats = 0;
      }
      if (options.repeats > this.forever) {
        options.repeats = this.forever;
      }
      if (options.until == null) {
        options.until = doc.repeatUntil;
      }
      if (options.wait == null) {
        options.wait = 0;
      }
      return this._rerun_job(doc, options.repeats, options.wait, options.until);
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobDone = function(id, runId, result, options) {
    var doc, ids, jobId, logObj, mods, n, num, time;
    check(id, Match.Where(_validId));
    check(runId, Match.Where(_validId));
    check(result, Object);
    check(options, Match.Optional({}));
    if (options == null) {
      options = {};
    }
    time = new Date();
    doc = this.findOne({
      _id: id,
      runId: runId,
      status: "running"
    }, {
      fields: {
        log: 0,
        failures: 0,
        progress: 0,
        updated: 0,
        after: 0,
        status: 0
      },
      transform: null
    });
    if (doc == null) {
      if (!this.isSimulation) {
        console.warn("Running job not found", id, runId);
      }
      return false;
    }
    mods = {
      $set: {
        status: "completed",
        result: result,
        progress: {
          completed: 1,
          total: 1,
          percent: 100
        },
        updated: time
      }
    };
    if (logObj = _logMessage.completed(runId)) {
      mods.$push = {
        log: logObj
      };
    }
    num = this.update({
      _id: id,
      runId: runId,
      status: "running"
    }, mods);
    if (num === 1) {
      if (doc.repeats > 0 && doc.repeatUntil - doc.repeatWait >= time) {
        jobId = this._rerun_job(doc);
      }
      ids = this.find({
        depends: {
          $all: [id]
        }
      }, {
        transform: null,
        fields: {
          _id: 1
        }
      }).fetch().map((function(_this) {
        return function(d) {
          return d._id;
        };
      })(this));
      if (ids.length > 0) {
        mods = {
          $pull: {
            depends: id
          },
          $push: {
            resolved: id
          }
        };
        if (logObj = _logMessage.resolved(id, runId)) {
          mods.$push.log = logObj;
        }
        n = this.update({
          _id: {
            $in: ids
          }
        }, mods, {
          multi: true
        });
        if (n !== ids.length) {
          console.warn("Not all dependent jobs were resolved " + ids.length + " > " + n);
        }
        if (typeof this._promote_jobs === "function") {
          this._promote_jobs(ids);
        }
      }
      return true;
    } else {
      console.warn("jobDone failed");
    }
    return false;
  };

  JobCollectionBase.prototype._DDPMethod_jobFail = function(id, runId, err, options) {
    var after, doc, logObj, mods, newStatus, num, time;
    check(id, Match.Where(_validId));
    check(runId, Match.Where(_validId));
    check(err, Object);
    check(options, Match.Optional({
      fatal: Match.Optional(Boolean)
    }));
    if (options == null) {
      options = {};
    }
    if (options.fatal == null) {
      options.fatal = false;
    }
    time = new Date();
    doc = this.findOne({
      _id: id,
      runId: runId,
      status: "running"
    }, {
      fields: {
        log: 0,
        failures: 0,
        progress: 0,
        updated: 0,
        after: 0,
        runId: 0,
        status: 0
      },
      transform: null
    });
    if (doc == null) {
      if (!this.isSimulation) {
        console.warn("Running job not found", id, runId);
      }
      return false;
    }
    after = (function() {
      switch (doc.retryBackoff) {
        case 'exponential':
          return new Date(time.valueOf() + doc.retryWait * Math.pow(2, doc.retried - 1));
        default:
          return new Date(time.valueOf() + doc.retryWait);
      }
    })();
    newStatus = !options.fatal && doc.retries > 0 && doc.retryUntil >= after ? "waiting" : "failed";
    err.runId = runId;
    mods = {
      $set: {
        status: newStatus,
        runId: null,
        after: after,
        progress: {
          completed: 0,
          total: 1,
          percent: 0
        },
        updated: time
      },
      $push: {
        failures: err
      }
    };
    if (logObj = _logMessage.failed(runId, options.fatal, err.value)) {
      mods.$push.log = logObj;
    }
    num = this.update({
      _id: id,
      runId: runId,
      status: "running"
    }, mods);
    if (newStatus === "failed" && num === 1) {
      this.find({
        depends: {
          $all: [id]
        }
      }, {
        transform: null
      }).forEach((function(_this) {
        return function(d) {
          return _this._DDPMethod_jobCancel(d._id);
        };
      })(this));
    }
    if (num === 1) {
      return true;
    } else {
      console.warn("jobFail failed");
    }
    return false;
  };

  return JobCollectionBase;

})(Mongo.Collection);

share.JobCollectionBase = JobCollectionBase;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi:job-collection/server.coffee.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var               
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
  __slice = [].slice;

if (Meteor.isServer) {
  JobCollection = (function(_super) {
    __extends(JobCollection, _super);

    function JobCollection(root, options) {
      var level, localMethods, methodFunction, methodName, _i, _len, _ref;
      if (root == null) {
        root = 'queue';
      }
      if (options == null) {
        options = {};
      }
      this._toLog = __bind(this._toLog, this);
      if (!(this instanceof JobCollection)) {
        return new JobCollection(root, options);
      }
      JobCollection.__super__.constructor.call(this, root, options);
      this.stopped = true;
      JobCollection.__super__.deny.bind(this)({
        update: (function(_this) {
          return function() {
            return true;
          };
        })(this),
        insert: (function(_this) {
          return function() {
            return true;
          };
        })(this),
        remove: (function(_this) {
          return function() {
            return true;
          };
        })(this)
      });
      this.promote();
      this.logStream = null;
      this.allows = {};
      this.denys = {};
      _ref = this.ddpPermissionLevels.concat(this.ddpMethods);
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        level = _ref[_i];
        this.allows[level] = [];
        this.denys[level] = [];
      }
      if (options.connection == null) {
        this._ensureIndex({
          type: 1,
          status: 1
        });
        this.isSimulation = false;
        localMethods = this._generateMethods();
        if (Job._localServerMethods == null) {
          Job._localServerMethods = {};
        }
        for (methodName in localMethods) {
          methodFunction = localMethods[methodName];
          Job._localServerMethods[methodName] = methodFunction;
        }
        Job._setDDPApply(function(name, params, cb) {
          if (cb != null) {
            return Meteor.setTimeout((function() {
              return cb(null, Job._localServerMethods[name].apply(this, params));
            }), 0);
          } else {
            return Job._localServerMethods[name].apply(this, params);
          }
        });
        Meteor.methods(localMethods);
      }
    }

    JobCollection.prototype._toLog = function(userId, method, message) {
      var _ref;
      return (_ref = this.logStream) != null ? _ref.write("" + (new Date()) + ", " + userId + ", " + method + ", " + message + "\n") : void 0;
    };

    JobCollection.prototype._methodWrapper = function(method, func) {
      var myTypeof, permitted, toLog;
      toLog = this._toLog;
      myTypeof = function(val) {
        var type;
        type = typeof val;
        if (type === 'object' && type instanceof Array) {
          type = 'array';
        }
        return type;
      };
      permitted = (function(_this) {
        return function(userId, params) {
          var performAllTests, performTest;
          performTest = function(tests) {
            var result, test, _i, _len;
            result = false;
            for (_i = 0, _len = tests.length; _i < _len; _i++) {
              test = tests[_i];
              if (result === false) {
                result = result || (function() {
                  switch (myTypeof(test)) {
                    case 'array':
                      return __indexOf.call(test, userId) >= 0;
                    case 'function':
                      return test(userId, method, params);
                    default:
                      return false;
                  }
                })();
              }
            }
            return result;
          };
          performAllTests = function(allTests) {
            var result, t, _i, _len, _ref;
            result = false;
            _ref = _this.ddpMethodPermissions[method];
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
              t = _ref[_i];
              if (result === false) {
                result = result || performTest(allTests[t]);
              }
            }
            return result;
          };
          return !performAllTests(_this.denys) && performAllTests(_this.allows);
        };
      })(this);
      return function() {
        var params, retval, user, _ref;
        params = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
        user = (_ref = this.userId) != null ? _ref : "[UNAUTHENTICATED]";
        if (!this.connection) {
          user = "[SERVER]";
        }
        toLog(user, method, "params: " + JSON.stringify(params));
        if (!(this.connection && !permitted(this.userId, params))) {
          retval = func.apply(null, params);
          toLog(user, method, "returned: " + JSON.stringify(retval));
          return retval;
        } else {
          toLog(this.userId, method, "UNAUTHORIZED.");
          throw new Meteor.Error(403, "Method not authorized", "Authenticated user is not permitted to invoke this method.");
        }
      };
    };

    JobCollection.prototype.setLogStream = function(writeStream) {
      if (writeStream == null) {
        writeStream = null;
      }
      if (this.logStream) {
        throw new Error("logStream may only be set once per job-collection startup/shutdown cycle");
      }
      this.logStream = writeStream;
      if (!((this.logStream == null) || (this.logStream.write != null) && typeof this.logStream.write === 'function' && (this.logStream.end != null) && typeof this.logStream.end === 'function')) {
        throw new Error("logStream must be a valid writable node.js Stream");
      }
    };

    JobCollection.prototype.allow = function(allowOptions) {
      var func, type, _results;
      _results = [];
      for (type in allowOptions) {
        func = allowOptions[type];
        if (type in this.allows) {
          _results.push(this.allows[type].push(func));
        }
      }
      return _results;
    };

    JobCollection.prototype.deny = function(denyOptions) {
      var func, type, _results;
      _results = [];
      for (type in denyOptions) {
        func = denyOptions[type];
        if (type in this.denys) {
          _results.push(this.denys[type].push(func));
        }
      }
      return _results;
    };

    JobCollection.prototype.scrub = function(job) {
      return job;
    };

    JobCollection.prototype.promote = function(milliseconds) {
      if (milliseconds == null) {
        milliseconds = 15 * 1000;
      }
      if (typeof milliseconds === 'number' && milliseconds > 0) {
        if (this.interval) {
          Meteor.clearInterval(this.interval);
        }
        return this.interval = Meteor.setInterval(this._promote_jobs.bind(this), milliseconds);
      } else {
        return console.warn("jobCollection.promote: invalid timeout: " + this.root + ", " + milliseconds);
      }
    };

    JobCollection.prototype._promote_jobs = function(ids) {
      var num, query, time;
      if (ids == null) {
        ids = [];
      }
      if (this.stopped) {
        return;
      }
      time = new Date();
      query = {
        status: "waiting",
        after: {
          $lte: time
        },
        depends: {
          $size: 0
        }
      };
      if (ids.length > 0) {
        query._id = {
          $in: ids
        };
      }
      return num = this.update(query, {
        $set: {
          status: "ready",
          updated: time
        },
        $push: {
          log: {
            time: time,
            runId: null,
            level: 'success',
            message: "Promoted to ready"
          }
        }
      }, {
        multi: true
      });
    };

    return JobCollection;

  })(share.JobCollectionBase);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['vsivsi:job-collection'] = {
  Job: Job,
  JobCollection: JobCollection
};

})();

//# sourceMappingURL=vsivsi_job-collection.js.map
