(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ReactiveVar = Package['reactive-var'].ReactiveVar;

/* Package-scope variables */
var Location;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/mirrorcell_geolocation-plus/lib/location.js                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var options = {                                                                                                      // 1
    persistent: true,                                                                                                // 2
    lazyLastPosition: false,                                                                                         // 3
    distanceFilter: {                                                                                                // 4
        enabled: false,                                                                                              // 5
        range: 5 // Meters                                                                                           // 6
    },                                                                                                               // 7
    timeFilter: {                                                                                                    // 8
        enabled: false,                                                                                              // 9
        span: 120 // Seconds                                                                                         // 10
    },                                                                                                               // 11
    accuracyFilter: {                                                                                                // 12
        enabled: false,                                                                                              // 13
        rating: 12 // Accuracy rating                                                                                // 14
    }                                                                                                                // 15
};                                                                                                                   // 16
                                                                                                                     // 17
var reactiveLocation = new ReactiveVar(null);                                                                        // 18
                                                                                                                     // 19
var watchOptions = {                                                                                                 // 20
    enableHighAccuracy: true,                                                                                        // 21
    maximumAge: 0                                                                                                    // 22
};                                                                                                                   // 23
var positionOptions = {                                                                                              // 24
  enableHighAccuracy: true,                                                                                          // 25
    maximumAge: 0                                                                                                    // 26
};                                                                                                                   // 27
                                                                                                                     // 28
                                                                                                                     // 29
function storePosition(pos) {                                                                                        // 30
                                                                                                                     // 31
    var p = {                                                                                                        // 32
        latitude: pos.coords.latitude,                                                                               // 33
        longitude: pos.coords.longitude,                                                                             // 34
        accuracy: pos.coords.accuracy,                                                                               // 35
        altitudeAccuracy: pos.coords.altitudeAccuracy,                                                               // 36
        speed: pos.coords.speed,                                                                                     // 37
        heading: pos.coords.heading,                                                                                 // 38
        updatedAt: pos.timestamp                                                                                     // 39
    };                                                                                                               // 40
                                                                                                                     // 41
    var string = JSON.stringify(p);                                                                                  // 42
                                                                                                                     // 43
    options.persistent && localStorage && localStorage.setItem('paulw:lastPosition', string);                        // 44
                                                                                                                     // 45
    reactiveLocation.set(p);                                                                                         // 46
                                                                                                                     // 47
    return p;                                                                                                        // 48
}                                                                                                                    // 49
                                                                                                                     // 50
function filter(pos) {                                                                                               // 51
    var old = Location && Location.getLastPosition();                                                                // 52
                                                                                                                     // 53
                                                                                                                     // 54
    if(!old) return pos; // We havent gotten a single position yet                                                   // 55
                                                                                                                     // 56
    if(Location._options.distanceFilter.enabled) {                                                                   // 57
        Location.debug && console.log("Filtering distance");                                                         // 58
        var d = getDistance(old, pos);                                                                               // 59
        Location.debug && console.log("Distance Filter: Filter - " + Location._options.distanceFilter.range + ". Actual Distance - " + d);
        if(!(d >= Location._options.distanceFilter.range)) {                                                         // 61
            return null;                                                                                             // 62
        }                                                                                                            // 63
    }                                                                                                                // 64
                                                                                                                     // 65
    if(Location._options.timeFilter.enabled) {                                                                       // 66
        var tf = isSecondsAway(new Date(old.updatedAt), Location._options.timeFilter.span);                          // 67
        Location.debug && console.log("Time Filter: Filter - Has Been " +                                            // 68
            Location._options.timeFilter.span + " Seconds? " + tf);                                                  // 69
        if(!tf) {                                                                                                    // 70
            return null;                                                                                             // 71
        }                                                                                                            // 72
    }                                                                                                                // 73
                                                                                                                     // 74
    if(Location._options.accuracyFilter.enabled && pos.coords.accuracy && !(isNaN(pos.coords.accuracy))) {           // 75
        Location.debug && console.log("Accuracy" + pos.coords.accuracy);                                             // 76
        if(pos.coords.accuracy > Location._options.accuracyFilter.rating) {                                          // 77
            Location.debug && console.log("Accuracy filter: Not accurate enough");                                   // 78
            return null;                                                                                             // 79
        }                                                                                                            // 80
    }                                                                                                                // 81
                                                                                                                     // 82
    return pos;                                                                                                      // 83
}                                                                                                                    // 84
                                                                                                                     // 85
function error(err) {                                                                                                // 86
    Session.set('paulw:locationError', err);                                                                         // 87
}                                                                                                                    // 88
                                                                                                                     // 89
Location = {                                                                                                         // 90
    _options : options,                                                                                              // 91
    _watchOptions: watchOptions,                                                                                     // 92
    _positionOptions: positionOptions,                                                                               // 93
    _position: null,                                                                                                 // 94
    _watching: false,                                                                                                // 95
    _watchId: null,                                                                                                  // 96
    debug: false,                                                                                                    // 97
    //This function calls my native utils package to retrieve the state of the GPS and if                            // 98
    //dialog is set to true, will show the user a prompt asking the user to turn on their GPS                        // 99
    getGPSState: function(callback, failureCallback, options) {                                                      // 100
        if(Meteor.isCordova && window && window.plugins && window.plugins.nativeUtils.getGPSState) {                 // 101
            window.plugins.nativeUtils.getGPSState(callback, failureCallback, options);                              // 102
        } else {                                                                                                     // 103
            //Throw enabled back if client is browser                                                                // 104
            callback && callback('Enabled');                                                                         // 105
        }                                                                                                            // 106
    },                                                                                                               // 107
    getReactivePosition : function() {                                                                               // 108
        return reactiveLocation.get();                                                                               // 109
    },                                                                                                               // 110
    getLastPosition : function() {                                                                                   // 111
        if(options.persistent) {                                                                                     // 112
            var lastPos = localStorage.getItem('paulw:lastPosition');                                                // 113
            if (lastPos)                                                                                             // 114
                return JSON.parse(lastPos);                                                                          // 115
            else                                                                                                     // 116
                return null;                                                                                         // 117
        } else {                                                                                                     // 118
            console.log("Location Error: You've set perstitent storage to false");                                   // 119
        }                                                                                                            // 120
    },                                                                                                               // 121
    locate : function(callback, failureCallback) {                                                                   // 122
        if(navigator.geolocation) {                                                                                  // 123
            navigator.geolocation.getCurrentPosition(function(pos) {                                                 // 124
                Location.debug && console.log("Get Current Position Received New Position: " + JSON.stringify(pos));
                var filtered = filter(pos);                                                                          // 126
                                                                                                                     // 127
                if(filtered) {                                                                                       // 128
                    var fixed = storePosition(filtered);                                                             // 129
                                                                                                                     // 130
                    callback && callback(fixed)                                                                      // 131
                }                                                                                                    // 132
                                                                                                                     // 133
            }, failureCallback, this._positionOptions);                                                              // 134
        }                                                                                                            // 135
    },                                                                                                               // 136
    startWatching : function(callback, failureCallback) {                                                            // 137
        if (!this._watching && navigator.geolocation) {                                                              // 138
            this._watchId = navigator.geolocation.watchPosition(function(pos) {                                      // 139
                Location.debug && console.log("Start Watching Received New Position: " + JSON.stringify(pos));       // 140
                var filtered = filter(pos);                                                                          // 141
                                                                                                                     // 142
                if(filtered) {                                                                                       // 143
                    var fixed = storePosition(pos);                                                                  // 144
                                                                                                                     // 145
                    callback && callback(fixed);                                                                     // 146
                }                                                                                                    // 147
                                                                                                                     // 148
            }, failureCallback, this._watchOptions);                                                                 // 149
            this._watching = true;                                                                                   // 150
        }                                                                                                            // 151
    },                                                                                                               // 152
    stopWatching : function() {                                                                                      // 153
        if (this._watching && navigator.geolocation) {                                                               // 154
            navigator.geolocation.clearWatch(this._watchId);                                                         // 155
            this._watching = false                                                                                   // 156
        }                                                                                                            // 157
    },                                                                                                               // 158
    setMockLocation : function(pos) {                                                                                // 159
        var p = {                                                                                                    // 160
            coords: {                                                                                                // 161
                latitude: pos.latitude || 0,                                                                         // 162
                longitude: pos.longitude || 0,                                                                       // 163
                accuracy: pos.accuracy || 0,                                                                         // 164
                altitudeAccuracy: pos.altitudeAccuracy || 0,                                                         // 165
                speed: pos.speed || 0,                                                                               // 166
                heading: pos.heading || 0                                                                            // 167
            },                                                                                                       // 168
            timestamp: pos.updatedAt || (new Date()).getTime()                                                       // 169
        };                                                                                                           // 170
                                                                                                                     // 171
        storePosition(p);                                                                                            // 172
    },                                                                                                               // 173
    setWatchOptions : function(options) {                                                                            // 174
        if(!options) {                                                                                               // 175
            console.log("You must provide an options object");                                                       // 176
        } else {                                                                                                     // 177
            this._watchOptions = options;                                                                            // 178
        }                                                                                                            // 179
    },                                                                                                               // 180
    setGetPositionOptions : function(options) {                                                                      // 181
        if(!options) {                                                                                               // 182
            console.log("You must provide an options object");                                                       // 183
        } else {                                                                                                     // 184
            this._positionOptions = options;                                                                         // 185
        }                                                                                                            // 186
    },                                                                                                               // 187
    enableAccuracyFilter: function(rating) {                                                                         // 188
        this._options.accuracyFilter.enabled = true;                                                                 // 189
        this._options.accuracyFilter.rating = rating;                                                                // 190
    },                                                                                                               // 191
    disableAccuracyFilter: function() {                                                                              // 192
        this._options.accuracyFilter.enabled = false;                                                                // 193
    },                                                                                                               // 194
    enableDistanceFilter: function(distance) {                                                                       // 195
        this._options.distanceFilter.enabled = true;                                                                 // 196
        this._options.distanceFilter.range = distance;                                                               // 197
    },                                                                                                               // 198
    disableDistanceFilter: function() {                                                                              // 199
        this._options.distanceFilter.enabled = false;                                                                // 200
    },                                                                                                               // 201
    enableTimeFilter: function(span) {                                                                               // 202
        this._options.timeFilter.enabled = true;                                                                     // 203
        this._options.timeFilter.span = span;                                                                        // 204
    },                                                                                                               // 205
    disableTimeFilter: function() {                                                                                  // 206
        this._options.timeFilter.enabled = false;                                                                    // 207
    },                                                                                                               // 208
    disableAllFilters: function() {                                                                                  // 209
        this._options.accuracyFilter.enabled = false;                                                                // 210
        this._options.distanceFilter.enabled = false;                                                                // 211
        this._options.timeFilter.enabled = false;                                                                    // 212
    }                                                                                                                // 213
};                                                                                                                   // 214
                                                                                                                     // 215
//Helpers                                                                                                            // 216
                                                                                                                     // 217
function rad(x) {                                                                                                    // 218
    return x * Math.PI / 180;                                                                                        // 219
};                                                                                                                   // 220
                                                                                                                     // 221
function getDistance(p1, p2) {                                                                                       // 222
    if (p1 && p2) {                                                                                                  // 223
        Location.debug && console.log("Getting distance for", p1, p2)                                                // 224
        var R = 6378137; // Earth’s mean radius in meter                                                             // 225
        var dLat = rad(p2.coords.latitude - p1.latitude);                                                            // 226
        var dLong = rad(p2.coords.longitude - p1.longitude);                                                         // 227
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +                                                            // 228
            Math.cos(rad(p1.latitude)) * Math.cos(rad(p2.coords.latitude)) *                                         // 229
            Math.sin(dLong / 2) * Math.sin(dLong / 2);                                                               // 230
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));                                                      // 231
        var d = R * c;                                                                                               // 232
        return d; // returns the distance in meters                                                                  // 233
    } else {                                                                                                         // 234
        // TODO: console log or throw error? Return what here?                                                       // 235
        return null;                                                                                                 // 236
    }                                                                                                                // 237
};                                                                                                                   // 238
                                                                                                                     // 239
function isSecondsAway(date, seconds) {                                                                              // 240
    var now = new Date();                                                                                            // 241
    Location.debug && console.log("Time Calc: " + (now.getTime() - date.getTime()));                                 // 242
    Location.debug && console.log(seconds + " Seconds: " + (seconds * 1000) + ' In Milliseconds');                   // 243
                                                                                                                     // 244
    return !((now.getTime() - date.getTime()) <= (seconds * 1000))                                                   // 245
};                                                                                                                   // 246
                                                                                                                     // 247
                                                                                                                     // 248
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mirrorcell:geolocation-plus'] = {
  Location: Location
};

})();
