(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var async;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// packages/peerlibrary:async/async/lib/async.js                                            //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
/*!                                                                                         // 1
 * async                                                                                    // 2
 * https://github.com/caolan/async                                                          // 3
 *                                                                                          // 4
 * Copyright 2010-2014 Caolan McMahon                                                       // 5
 * Released under the MIT license                                                           // 6
 */                                                                                         // 7
/*jshint onevar: false, indent:4 */                                                         // 8
/*global setImmediate: false, setTimeout: false, console: false */                          // 9
(function () {                                                                              // 10
                                                                                            // 11
    var async = {};                                                                         // 12
                                                                                            // 13
    // global on the server, window in the browser                                          // 14
    var root, previous_async;                                                               // 15
                                                                                            // 16
    root = this;                                                                            // 17
    if (root != null) {                                                                     // 18
      previous_async = root.async;                                                          // 19
    }                                                                                       // 20
                                                                                            // 21
    async.noConflict = function () {                                                        // 22
        root.async = previous_async;                                                        // 23
        return async;                                                                       // 24
    };                                                                                      // 25
                                                                                            // 26
    function only_once(fn) {                                                                // 27
        var called = false;                                                                 // 28
        return function() {                                                                 // 29
            if (called) throw new Error("Callback was already called.");                    // 30
            called = true;                                                                  // 31
            fn.apply(root, arguments);                                                      // 32
        }                                                                                   // 33
    }                                                                                       // 34
                                                                                            // 35
    //// cross-browser compatiblity functions ////                                          // 36
                                                                                            // 37
    var _toString = Object.prototype.toString;                                              // 38
                                                                                            // 39
    var _isArray = Array.isArray || function (obj) {                                        // 40
        return _toString.call(obj) === '[object Array]';                                    // 41
    };                                                                                      // 42
                                                                                            // 43
    var _each = function (arr, iterator) {                                                  // 44
        for (var i = 0; i < arr.length; i += 1) {                                           // 45
            iterator(arr[i], i, arr);                                                       // 46
        }                                                                                   // 47
    };                                                                                      // 48
                                                                                            // 49
    var _map = function (arr, iterator) {                                                   // 50
        if (arr.map) {                                                                      // 51
            return arr.map(iterator);                                                       // 52
        }                                                                                   // 53
        var results = [];                                                                   // 54
        _each(arr, function (x, i, a) {                                                     // 55
            results.push(iterator(x, i, a));                                                // 56
        });                                                                                 // 57
        return results;                                                                     // 58
    };                                                                                      // 59
                                                                                            // 60
    var _reduce = function (arr, iterator, memo) {                                          // 61
        if (arr.reduce) {                                                                   // 62
            return arr.reduce(iterator, memo);                                              // 63
        }                                                                                   // 64
        _each(arr, function (x, i, a) {                                                     // 65
            memo = iterator(memo, x, i, a);                                                 // 66
        });                                                                                 // 67
        return memo;                                                                        // 68
    };                                                                                      // 69
                                                                                            // 70
    var _keys = function (obj) {                                                            // 71
        if (Object.keys) {                                                                  // 72
            return Object.keys(obj);                                                        // 73
        }                                                                                   // 74
        var keys = [];                                                                      // 75
        for (var k in obj) {                                                                // 76
            if (obj.hasOwnProperty(k)) {                                                    // 77
                keys.push(k);                                                               // 78
            }                                                                               // 79
        }                                                                                   // 80
        return keys;                                                                        // 81
    };                                                                                      // 82
                                                                                            // 83
    //// exported async module functions ////                                               // 84
                                                                                            // 85
    //// nextTick implementation with browser-compatible fallback ////                      // 86
    if (typeof process === 'undefined' || !(process.nextTick)) {                            // 87
        if (typeof setImmediate === 'function') {                                           // 88
            async.nextTick = function (fn) {                                                // 89
                // not a direct alias for IE10 compatibility                                // 90
                setImmediate(fn);                                                           // 91
            };                                                                              // 92
            async.setImmediate = async.nextTick;                                            // 93
        }                                                                                   // 94
        else {                                                                              // 95
            async.nextTick = function (fn) {                                                // 96
                setTimeout(fn, 0);                                                          // 97
            };                                                                              // 98
            async.setImmediate = async.nextTick;                                            // 99
        }                                                                                   // 100
    }                                                                                       // 101
    else {                                                                                  // 102
        async.nextTick = process.nextTick;                                                  // 103
        if (typeof setImmediate !== 'undefined') {                                          // 104
            async.setImmediate = function (fn) {                                            // 105
              // not a direct alias for IE10 compatibility                                  // 106
              setImmediate(fn);                                                             // 107
            };                                                                              // 108
        }                                                                                   // 109
        else {                                                                              // 110
            async.setImmediate = async.nextTick;                                            // 111
        }                                                                                   // 112
    }                                                                                       // 113
                                                                                            // 114
    async.each = function (arr, iterator, callback) {                                       // 115
        callback = callback || function () {};                                              // 116
        if (!arr.length) {                                                                  // 117
            return callback();                                                              // 118
        }                                                                                   // 119
        var completed = 0;                                                                  // 120
        _each(arr, function (x) {                                                           // 121
            iterator(x, only_once(done) );                                                  // 122
        });                                                                                 // 123
        function done(err) {                                                                // 124
          if (err) {                                                                        // 125
              callback(err);                                                                // 126
              callback = function () {};                                                    // 127
          }                                                                                 // 128
          else {                                                                            // 129
              completed += 1;                                                               // 130
              if (completed >= arr.length) {                                                // 131
                  callback();                                                               // 132
              }                                                                             // 133
          }                                                                                 // 134
        }                                                                                   // 135
    };                                                                                      // 136
    async.forEach = async.each;                                                             // 137
                                                                                            // 138
    async.eachSeries = function (arr, iterator, callback) {                                 // 139
        callback = callback || function () {};                                              // 140
        if (!arr.length) {                                                                  // 141
            return callback();                                                              // 142
        }                                                                                   // 143
        var completed = 0;                                                                  // 144
        var iterate = function () {                                                         // 145
            iterator(arr[completed], function (err) {                                       // 146
                if (err) {                                                                  // 147
                    callback(err);                                                          // 148
                    callback = function () {};                                              // 149
                }                                                                           // 150
                else {                                                                      // 151
                    completed += 1;                                                         // 152
                    if (completed >= arr.length) {                                          // 153
                        callback();                                                         // 154
                    }                                                                       // 155
                    else {                                                                  // 156
                        iterate();                                                          // 157
                    }                                                                       // 158
                }                                                                           // 159
            });                                                                             // 160
        };                                                                                  // 161
        iterate();                                                                          // 162
    };                                                                                      // 163
    async.forEachSeries = async.eachSeries;                                                 // 164
                                                                                            // 165
    async.eachLimit = function (arr, limit, iterator, callback) {                           // 166
        var fn = _eachLimit(limit);                                                         // 167
        fn.apply(null, [arr, iterator, callback]);                                          // 168
    };                                                                                      // 169
    async.forEachLimit = async.eachLimit;                                                   // 170
                                                                                            // 171
    var _eachLimit = function (limit) {                                                     // 172
                                                                                            // 173
        return function (arr, iterator, callback) {                                         // 174
            callback = callback || function () {};                                          // 175
            if (!arr.length || limit <= 0) {                                                // 176
                return callback();                                                          // 177
            }                                                                               // 178
            var completed = 0;                                                              // 179
            var started = 0;                                                                // 180
            var running = 0;                                                                // 181
                                                                                            // 182
            (function replenish () {                                                        // 183
                if (completed >= arr.length) {                                              // 184
                    return callback();                                                      // 185
                }                                                                           // 186
                                                                                            // 187
                while (running < limit && started < arr.length) {                           // 188
                    started += 1;                                                           // 189
                    running += 1;                                                           // 190
                    iterator(arr[started - 1], function (err) {                             // 191
                        if (err) {                                                          // 192
                            callback(err);                                                  // 193
                            callback = function () {};                                      // 194
                        }                                                                   // 195
                        else {                                                              // 196
                            completed += 1;                                                 // 197
                            running -= 1;                                                   // 198
                            if (completed >= arr.length) {                                  // 199
                                callback();                                                 // 200
                            }                                                               // 201
                            else {                                                          // 202
                                replenish();                                                // 203
                            }                                                               // 204
                        }                                                                   // 205
                    });                                                                     // 206
                }                                                                           // 207
            })();                                                                           // 208
        };                                                                                  // 209
    };                                                                                      // 210
                                                                                            // 211
                                                                                            // 212
    var doParallel = function (fn) {                                                        // 213
        return function () {                                                                // 214
            var args = Array.prototype.slice.call(arguments);                               // 215
            return fn.apply(null, [async.each].concat(args));                               // 216
        };                                                                                  // 217
    };                                                                                      // 218
    var doParallelLimit = function(limit, fn) {                                             // 219
        return function () {                                                                // 220
            var args = Array.prototype.slice.call(arguments);                               // 221
            return fn.apply(null, [_eachLimit(limit)].concat(args));                        // 222
        };                                                                                  // 223
    };                                                                                      // 224
    var doSeries = function (fn) {                                                          // 225
        return function () {                                                                // 226
            var args = Array.prototype.slice.call(arguments);                               // 227
            return fn.apply(null, [async.eachSeries].concat(args));                         // 228
        };                                                                                  // 229
    };                                                                                      // 230
                                                                                            // 231
                                                                                            // 232
    var _asyncMap = function (eachfn, arr, iterator, callback) {                            // 233
        arr = _map(arr, function (x, i) {                                                   // 234
            return {index: i, value: x};                                                    // 235
        });                                                                                 // 236
        if (!callback) {                                                                    // 237
            eachfn(arr, function (x, callback) {                                            // 238
                iterator(x.value, function (err) {                                          // 239
                    callback(err);                                                          // 240
                });                                                                         // 241
            });                                                                             // 242
        } else {                                                                            // 243
            var results = [];                                                               // 244
            eachfn(arr, function (x, callback) {                                            // 245
                iterator(x.value, function (err, v) {                                       // 246
                    results[x.index] = v;                                                   // 247
                    callback(err);                                                          // 248
                });                                                                         // 249
            }, function (err) {                                                             // 250
                callback(err, results);                                                     // 251
            });                                                                             // 252
        }                                                                                   // 253
    };                                                                                      // 254
    async.map = doParallel(_asyncMap);                                                      // 255
    async.mapSeries = doSeries(_asyncMap);                                                  // 256
    async.mapLimit = function (arr, limit, iterator, callback) {                            // 257
        return _mapLimit(limit)(arr, iterator, callback);                                   // 258
    };                                                                                      // 259
                                                                                            // 260
    var _mapLimit = function(limit) {                                                       // 261
        return doParallelLimit(limit, _asyncMap);                                           // 262
    };                                                                                      // 263
                                                                                            // 264
    // reduce only has a series version, as doing reduce in parallel won't                  // 265
    // work in many situations.                                                             // 266
    async.reduce = function (arr, memo, iterator, callback) {                               // 267
        async.eachSeries(arr, function (x, callback) {                                      // 268
            iterator(memo, x, function (err, v) {                                           // 269
                memo = v;                                                                   // 270
                callback(err);                                                              // 271
            });                                                                             // 272
        }, function (err) {                                                                 // 273
            callback(err, memo);                                                            // 274
        });                                                                                 // 275
    };                                                                                      // 276
    // inject alias                                                                         // 277
    async.inject = async.reduce;                                                            // 278
    // foldl alias                                                                          // 279
    async.foldl = async.reduce;                                                             // 280
                                                                                            // 281
    async.reduceRight = function (arr, memo, iterator, callback) {                          // 282
        var reversed = _map(arr, function (x) {                                             // 283
            return x;                                                                       // 284
        }).reverse();                                                                       // 285
        async.reduce(reversed, memo, iterator, callback);                                   // 286
    };                                                                                      // 287
    // foldr alias                                                                          // 288
    async.foldr = async.reduceRight;                                                        // 289
                                                                                            // 290
    var _filter = function (eachfn, arr, iterator, callback) {                              // 291
        var results = [];                                                                   // 292
        arr = _map(arr, function (x, i) {                                                   // 293
            return {index: i, value: x};                                                    // 294
        });                                                                                 // 295
        eachfn(arr, function (x, callback) {                                                // 296
            iterator(x.value, function (v) {                                                // 297
                if (v) {                                                                    // 298
                    results.push(x);                                                        // 299
                }                                                                           // 300
                callback();                                                                 // 301
            });                                                                             // 302
        }, function (err) {                                                                 // 303
            callback(_map(results.sort(function (a, b) {                                    // 304
                return a.index - b.index;                                                   // 305
            }), function (x) {                                                              // 306
                return x.value;                                                             // 307
            }));                                                                            // 308
        });                                                                                 // 309
    };                                                                                      // 310
    async.filter = doParallel(_filter);                                                     // 311
    async.filterSeries = doSeries(_filter);                                                 // 312
    // select alias                                                                         // 313
    async.select = async.filter;                                                            // 314
    async.selectSeries = async.filterSeries;                                                // 315
                                                                                            // 316
    var _reject = function (eachfn, arr, iterator, callback) {                              // 317
        var results = [];                                                                   // 318
        arr = _map(arr, function (x, i) {                                                   // 319
            return {index: i, value: x};                                                    // 320
        });                                                                                 // 321
        eachfn(arr, function (x, callback) {                                                // 322
            iterator(x.value, function (v) {                                                // 323
                if (!v) {                                                                   // 324
                    results.push(x);                                                        // 325
                }                                                                           // 326
                callback();                                                                 // 327
            });                                                                             // 328
        }, function (err) {                                                                 // 329
            callback(_map(results.sort(function (a, b) {                                    // 330
                return a.index - b.index;                                                   // 331
            }), function (x) {                                                              // 332
                return x.value;                                                             // 333
            }));                                                                            // 334
        });                                                                                 // 335
    };                                                                                      // 336
    async.reject = doParallel(_reject);                                                     // 337
    async.rejectSeries = doSeries(_reject);                                                 // 338
                                                                                            // 339
    var _detect = function (eachfn, arr, iterator, main_callback) {                         // 340
        eachfn(arr, function (x, callback) {                                                // 341
            iterator(x, function (result) {                                                 // 342
                if (result) {                                                               // 343
                    main_callback(x);                                                       // 344
                    main_callback = function () {};                                         // 345
                }                                                                           // 346
                else {                                                                      // 347
                    callback();                                                             // 348
                }                                                                           // 349
            });                                                                             // 350
        }, function (err) {                                                                 // 351
            main_callback();                                                                // 352
        });                                                                                 // 353
    };                                                                                      // 354
    async.detect = doParallel(_detect);                                                     // 355
    async.detectSeries = doSeries(_detect);                                                 // 356
                                                                                            // 357
    async.some = function (arr, iterator, main_callback) {                                  // 358
        async.each(arr, function (x, callback) {                                            // 359
            iterator(x, function (v) {                                                      // 360
                if (v) {                                                                    // 361
                    main_callback(true);                                                    // 362
                    main_callback = function () {};                                         // 363
                }                                                                           // 364
                callback();                                                                 // 365
            });                                                                             // 366
        }, function (err) {                                                                 // 367
            main_callback(false);                                                           // 368
        });                                                                                 // 369
    };                                                                                      // 370
    // any alias                                                                            // 371
    async.any = async.some;                                                                 // 372
                                                                                            // 373
    async.every = function (arr, iterator, main_callback) {                                 // 374
        async.each(arr, function (x, callback) {                                            // 375
            iterator(x, function (v) {                                                      // 376
                if (!v) {                                                                   // 377
                    main_callback(false);                                                   // 378
                    main_callback = function () {};                                         // 379
                }                                                                           // 380
                callback();                                                                 // 381
            });                                                                             // 382
        }, function (err) {                                                                 // 383
            main_callback(true);                                                            // 384
        });                                                                                 // 385
    };                                                                                      // 386
    // all alias                                                                            // 387
    async.all = async.every;                                                                // 388
                                                                                            // 389
    async.sortBy = function (arr, iterator, callback) {                                     // 390
        async.map(arr, function (x, callback) {                                             // 391
            iterator(x, function (err, criteria) {                                          // 392
                if (err) {                                                                  // 393
                    callback(err);                                                          // 394
                }                                                                           // 395
                else {                                                                      // 396
                    callback(null, {value: x, criteria: criteria});                         // 397
                }                                                                           // 398
            });                                                                             // 399
        }, function (err, results) {                                                        // 400
            if (err) {                                                                      // 401
                return callback(err);                                                       // 402
            }                                                                               // 403
            else {                                                                          // 404
                var fn = function (left, right) {                                           // 405
                    var a = left.criteria, b = right.criteria;                              // 406
                    return a < b ? -1 : a > b ? 1 : 0;                                      // 407
                };                                                                          // 408
                callback(null, _map(results.sort(fn), function (x) {                        // 409
                    return x.value;                                                         // 410
                }));                                                                        // 411
            }                                                                               // 412
        });                                                                                 // 413
    };                                                                                      // 414
                                                                                            // 415
    async.auto = function (tasks, callback) {                                               // 416
        callback = callback || function () {};                                              // 417
        var keys = _keys(tasks);                                                            // 418
        var remainingTasks = keys.length                                                    // 419
        if (!remainingTasks) {                                                              // 420
            return callback();                                                              // 421
        }                                                                                   // 422
                                                                                            // 423
        var results = {};                                                                   // 424
                                                                                            // 425
        var listeners = [];                                                                 // 426
        var addListener = function (fn) {                                                   // 427
            listeners.unshift(fn);                                                          // 428
        };                                                                                  // 429
        var removeListener = function (fn) {                                                // 430
            for (var i = 0; i < listeners.length; i += 1) {                                 // 431
                if (listeners[i] === fn) {                                                  // 432
                    listeners.splice(i, 1);                                                 // 433
                    return;                                                                 // 434
                }                                                                           // 435
            }                                                                               // 436
        };                                                                                  // 437
        var taskComplete = function () {                                                    // 438
            remainingTasks--                                                                // 439
            _each(listeners.slice(0), function (fn) {                                       // 440
                fn();                                                                       // 441
            });                                                                             // 442
        };                                                                                  // 443
                                                                                            // 444
        addListener(function () {                                                           // 445
            if (!remainingTasks) {                                                          // 446
                var theCallback = callback;                                                 // 447
                // prevent final callback from calling itself if it errors                  // 448
                callback = function () {};                                                  // 449
                                                                                            // 450
                theCallback(null, results);                                                 // 451
            }                                                                               // 452
        });                                                                                 // 453
                                                                                            // 454
        _each(keys, function (k) {                                                          // 455
            var task = _isArray(tasks[k]) ? tasks[k]: [tasks[k]];                           // 456
            var taskCallback = function (err) {                                             // 457
                var args = Array.prototype.slice.call(arguments, 1);                        // 458
                if (args.length <= 1) {                                                     // 459
                    args = args[0];                                                         // 460
                }                                                                           // 461
                if (err) {                                                                  // 462
                    var safeResults = {};                                                   // 463
                    _each(_keys(results), function(rkey) {                                  // 464
                        safeResults[rkey] = results[rkey];                                  // 465
                    });                                                                     // 466
                    safeResults[k] = args;                                                  // 467
                    callback(err, safeResults);                                             // 468
                    // stop subsequent errors hitting callback multiple times               // 469
                    callback = function () {};                                              // 470
                }                                                                           // 471
                else {                                                                      // 472
                    results[k] = args;                                                      // 473
                    async.setImmediate(taskComplete);                                       // 474
                }                                                                           // 475
            };                                                                              // 476
            var requires = task.slice(0, Math.abs(task.length - 1)) || [];                  // 477
            var ready = function () {                                                       // 478
                return _reduce(requires, function (a, x) {                                  // 479
                    return (a && results.hasOwnProperty(x));                                // 480
                }, true) && !results.hasOwnProperty(k);                                     // 481
            };                                                                              // 482
            if (ready()) {                                                                  // 483
                task[task.length - 1](taskCallback, results);                               // 484
            }                                                                               // 485
            else {                                                                          // 486
                var listener = function () {                                                // 487
                    if (ready()) {                                                          // 488
                        removeListener(listener);                                           // 489
                        task[task.length - 1](taskCallback, results);                       // 490
                    }                                                                       // 491
                };                                                                          // 492
                addListener(listener);                                                      // 493
            }                                                                               // 494
        });                                                                                 // 495
    };                                                                                      // 496
                                                                                            // 497
    async.retry = function(times, task, callback) {                                         // 498
        var DEFAULT_TIMES = 5;                                                              // 499
        var attempts = [];                                                                  // 500
        // Use defaults if times not passed                                                 // 501
        if (typeof times === 'function') {                                                  // 502
            callback = task;                                                                // 503
            task = times;                                                                   // 504
            times = DEFAULT_TIMES;                                                          // 505
        }                                                                                   // 506
        // Make sure times is a number                                                      // 507
        times = parseInt(times, 10) || DEFAULT_TIMES;                                       // 508
        var wrappedTask = function(wrappedCallback, wrappedResults) {                       // 509
            var retryAttempt = function(task, finalAttempt) {                               // 510
                return function(seriesCallback) {                                           // 511
                    task(function(err, result){                                             // 512
                        seriesCallback(!err || finalAttempt, {err: err, result: result});   // 513
                    }, wrappedResults);                                                     // 514
                };                                                                          // 515
            };                                                                              // 516
            while (times) {                                                                 // 517
                attempts.push(retryAttempt(task, !(times-=1)));                             // 518
            }                                                                               // 519
            async.series(attempts, function(done, data){                                    // 520
                data = data[data.length - 1];                                               // 521
                (wrappedCallback || callback)(data.err, data.result);                       // 522
            });                                                                             // 523
        }                                                                                   // 524
        // If a callback is passed, run this as a controll flow                             // 525
        return callback ? wrappedTask() : wrappedTask                                       // 526
    };                                                                                      // 527
                                                                                            // 528
    async.waterfall = function (tasks, callback) {                                          // 529
        callback = callback || function () {};                                              // 530
        if (!_isArray(tasks)) {                                                             // 531
          var err = new Error('First argument to waterfall must be an array of functions'); // 532
          return callback(err);                                                             // 533
        }                                                                                   // 534
        if (!tasks.length) {                                                                // 535
            return callback();                                                              // 536
        }                                                                                   // 537
        var wrapIterator = function (iterator) {                                            // 538
            return function (err) {                                                         // 539
                if (err) {                                                                  // 540
                    callback.apply(null, arguments);                                        // 541
                    callback = function () {};                                              // 542
                }                                                                           // 543
                else {                                                                      // 544
                    var args = Array.prototype.slice.call(arguments, 1);                    // 545
                    var next = iterator.next();                                             // 546
                    if (next) {                                                             // 547
                        args.push(wrapIterator(next));                                      // 548
                    }                                                                       // 549
                    else {                                                                  // 550
                        args.push(callback);                                                // 551
                    }                                                                       // 552
                    async.setImmediate(function () {                                        // 553
                        iterator.apply(null, args);                                         // 554
                    });                                                                     // 555
                }                                                                           // 556
            };                                                                              // 557
        };                                                                                  // 558
        wrapIterator(async.iterator(tasks))();                                              // 559
    };                                                                                      // 560
                                                                                            // 561
    var _parallel = function(eachfn, tasks, callback) {                                     // 562
        callback = callback || function () {};                                              // 563
        if (_isArray(tasks)) {                                                              // 564
            eachfn.map(tasks, function (fn, callback) {                                     // 565
                if (fn) {                                                                   // 566
                    fn(function (err) {                                                     // 567
                        var args = Array.prototype.slice.call(arguments, 1);                // 568
                        if (args.length <= 1) {                                             // 569
                            args = args[0];                                                 // 570
                        }                                                                   // 571
                        callback.call(null, err, args);                                     // 572
                    });                                                                     // 573
                }                                                                           // 574
            }, callback);                                                                   // 575
        }                                                                                   // 576
        else {                                                                              // 577
            var results = {};                                                               // 578
            eachfn.each(_keys(tasks), function (k, callback) {                              // 579
                tasks[k](function (err) {                                                   // 580
                    var args = Array.prototype.slice.call(arguments, 1);                    // 581
                    if (args.length <= 1) {                                                 // 582
                        args = args[0];                                                     // 583
                    }                                                                       // 584
                    results[k] = args;                                                      // 585
                    callback(err);                                                          // 586
                });                                                                         // 587
            }, function (err) {                                                             // 588
                callback(err, results);                                                     // 589
            });                                                                             // 590
        }                                                                                   // 591
    };                                                                                      // 592
                                                                                            // 593
    async.parallel = function (tasks, callback) {                                           // 594
        _parallel({ map: async.map, each: async.each }, tasks, callback);                   // 595
    };                                                                                      // 596
                                                                                            // 597
    async.parallelLimit = function(tasks, limit, callback) {                                // 598
        _parallel({ map: _mapLimit(limit), each: _eachLimit(limit) }, tasks, callback);     // 599
    };                                                                                      // 600
                                                                                            // 601
    async.series = function (tasks, callback) {                                             // 602
        callback = callback || function () {};                                              // 603
        if (_isArray(tasks)) {                                                              // 604
            async.mapSeries(tasks, function (fn, callback) {                                // 605
                if (fn) {                                                                   // 606
                    fn(function (err) {                                                     // 607
                        var args = Array.prototype.slice.call(arguments, 1);                // 608
                        if (args.length <= 1) {                                             // 609
                            args = args[0];                                                 // 610
                        }                                                                   // 611
                        callback.call(null, err, args);                                     // 612
                    });                                                                     // 613
                }                                                                           // 614
            }, callback);                                                                   // 615
        }                                                                                   // 616
        else {                                                                              // 617
            var results = {};                                                               // 618
            async.eachSeries(_keys(tasks), function (k, callback) {                         // 619
                tasks[k](function (err) {                                                   // 620
                    var args = Array.prototype.slice.call(arguments, 1);                    // 621
                    if (args.length <= 1) {                                                 // 622
                        args = args[0];                                                     // 623
                    }                                                                       // 624
                    results[k] = args;                                                      // 625
                    callback(err);                                                          // 626
                });                                                                         // 627
            }, function (err) {                                                             // 628
                callback(err, results);                                                     // 629
            });                                                                             // 630
        }                                                                                   // 631
    };                                                                                      // 632
                                                                                            // 633
    async.iterator = function (tasks) {                                                     // 634
        var makeCallback = function (index) {                                               // 635
            var fn = function () {                                                          // 636
                if (tasks.length) {                                                         // 637
                    tasks[index].apply(null, arguments);                                    // 638
                }                                                                           // 639
                return fn.next();                                                           // 640
            };                                                                              // 641
            fn.next = function () {                                                         // 642
                return (index < tasks.length - 1) ? makeCallback(index + 1): null;          // 643
            };                                                                              // 644
            return fn;                                                                      // 645
        };                                                                                  // 646
        return makeCallback(0);                                                             // 647
    };                                                                                      // 648
                                                                                            // 649
    async.apply = function (fn) {                                                           // 650
        var args = Array.prototype.slice.call(arguments, 1);                                // 651
        return function () {                                                                // 652
            return fn.apply(                                                                // 653
                null, args.concat(Array.prototype.slice.call(arguments))                    // 654
            );                                                                              // 655
        };                                                                                  // 656
    };                                                                                      // 657
                                                                                            // 658
    var _concat = function (eachfn, arr, fn, callback) {                                    // 659
        var r = [];                                                                         // 660
        eachfn(arr, function (x, cb) {                                                      // 661
            fn(x, function (err, y) {                                                       // 662
                r = r.concat(y || []);                                                      // 663
                cb(err);                                                                    // 664
            });                                                                             // 665
        }, function (err) {                                                                 // 666
            callback(err, r);                                                               // 667
        });                                                                                 // 668
    };                                                                                      // 669
    async.concat = doParallel(_concat);                                                     // 670
    async.concatSeries = doSeries(_concat);                                                 // 671
                                                                                            // 672
    async.whilst = function (test, iterator, callback) {                                    // 673
        if (test()) {                                                                       // 674
            iterator(function (err) {                                                       // 675
                if (err) {                                                                  // 676
                    return callback(err);                                                   // 677
                }                                                                           // 678
                async.whilst(test, iterator, callback);                                     // 679
            });                                                                             // 680
        }                                                                                   // 681
        else {                                                                              // 682
            callback();                                                                     // 683
        }                                                                                   // 684
    };                                                                                      // 685
                                                                                            // 686
    async.doWhilst = function (iterator, test, callback) {                                  // 687
        iterator(function (err) {                                                           // 688
            if (err) {                                                                      // 689
                return callback(err);                                                       // 690
            }                                                                               // 691
            var args = Array.prototype.slice.call(arguments, 1);                            // 692
            if (test.apply(null, args)) {                                                   // 693
                async.doWhilst(iterator, test, callback);                                   // 694
            }                                                                               // 695
            else {                                                                          // 696
                callback();                                                                 // 697
            }                                                                               // 698
        });                                                                                 // 699
    };                                                                                      // 700
                                                                                            // 701
    async.until = function (test, iterator, callback) {                                     // 702
        if (!test()) {                                                                      // 703
            iterator(function (err) {                                                       // 704
                if (err) {                                                                  // 705
                    return callback(err);                                                   // 706
                }                                                                           // 707
                async.until(test, iterator, callback);                                      // 708
            });                                                                             // 709
        }                                                                                   // 710
        else {                                                                              // 711
            callback();                                                                     // 712
        }                                                                                   // 713
    };                                                                                      // 714
                                                                                            // 715
    async.doUntil = function (iterator, test, callback) {                                   // 716
        iterator(function (err) {                                                           // 717
            if (err) {                                                                      // 718
                return callback(err);                                                       // 719
            }                                                                               // 720
            var args = Array.prototype.slice.call(arguments, 1);                            // 721
            if (!test.apply(null, args)) {                                                  // 722
                async.doUntil(iterator, test, callback);                                    // 723
            }                                                                               // 724
            else {                                                                          // 725
                callback();                                                                 // 726
            }                                                                               // 727
        });                                                                                 // 728
    };                                                                                      // 729
                                                                                            // 730
    async.queue = function (worker, concurrency) {                                          // 731
        if (concurrency === undefined) {                                                    // 732
            concurrency = 1;                                                                // 733
        }                                                                                   // 734
        function _insert(q, data, pos, callback) {                                          // 735
          if (!q.started){                                                                  // 736
            q.started = true;                                                               // 737
          }                                                                                 // 738
          if (!_isArray(data)) {                                                            // 739
              data = [data];                                                                // 740
          }                                                                                 // 741
          if(data.length == 0) {                                                            // 742
             // call drain immediately if there are no tasks                                // 743
             return async.setImmediate(function() {                                         // 744
                 if (q.drain) {                                                             // 745
                     q.drain();                                                             // 746
                 }                                                                          // 747
             });                                                                            // 748
          }                                                                                 // 749
          _each(data, function(task) {                                                      // 750
              var item = {                                                                  // 751
                  data: task,                                                               // 752
                  callback: typeof callback === 'function' ? callback : null                // 753
              };                                                                            // 754
                                                                                            // 755
              if (pos) {                                                                    // 756
                q.tasks.unshift(item);                                                      // 757
              } else {                                                                      // 758
                q.tasks.push(item);                                                         // 759
              }                                                                             // 760
                                                                                            // 761
              if (q.saturated && q.tasks.length === q.concurrency) {                        // 762
                  q.saturated();                                                            // 763
              }                                                                             // 764
              async.setImmediate(q.process);                                                // 765
          });                                                                               // 766
        }                                                                                   // 767
                                                                                            // 768
        var workers = 0;                                                                    // 769
        var q = {                                                                           // 770
            tasks: [],                                                                      // 771
            concurrency: concurrency,                                                       // 772
            saturated: null,                                                                // 773
            empty: null,                                                                    // 774
            drain: null,                                                                    // 775
            started: false,                                                                 // 776
            paused: false,                                                                  // 777
            push: function (data, callback) {                                               // 778
              _insert(q, data, false, callback);                                            // 779
            },                                                                              // 780
            kill: function () {                                                             // 781
              q.drain = null;                                                               // 782
              q.tasks = [];                                                                 // 783
            },                                                                              // 784
            unshift: function (data, callback) {                                            // 785
              _insert(q, data, true, callback);                                             // 786
            },                                                                              // 787
            process: function () {                                                          // 788
                if (!q.paused && workers < q.concurrency && q.tasks.length) {               // 789
                    var task = q.tasks.shift();                                             // 790
                    if (q.empty && q.tasks.length === 0) {                                  // 791
                        q.empty();                                                          // 792
                    }                                                                       // 793
                    workers += 1;                                                           // 794
                    var next = function () {                                                // 795
                        workers -= 1;                                                       // 796
                        if (task.callback) {                                                // 797
                            task.callback.apply(task, arguments);                           // 798
                        }                                                                   // 799
                        if (q.drain && q.tasks.length + workers === 0) {                    // 800
                            q.drain();                                                      // 801
                        }                                                                   // 802
                        q.process();                                                        // 803
                    };                                                                      // 804
                    var cb = only_once(next);                                               // 805
                    worker(task.data, cb);                                                  // 806
                }                                                                           // 807
            },                                                                              // 808
            length: function () {                                                           // 809
                return q.tasks.length;                                                      // 810
            },                                                                              // 811
            running: function () {                                                          // 812
                return workers;                                                             // 813
            },                                                                              // 814
            idle: function() {                                                              // 815
                return q.tasks.length + workers === 0;                                      // 816
            },                                                                              // 817
            pause: function () {                                                            // 818
                if (q.paused === true) { return; }                                          // 819
                q.paused = true;                                                            // 820
            },                                                                              // 821
            resume: function () {                                                           // 822
                if (q.paused === false) { return; }                                         // 823
                q.paused = false;                                                           // 824
                // Need to call q.process once per concurrent                               // 825
                // worker to preserve full concurrency after pause                          // 826
                for (var w = 1; w <= q.concurrency; w++) {                                  // 827
                    async.setImmediate(q.process);                                          // 828
                }                                                                           // 829
            }                                                                               // 830
        };                                                                                  // 831
        return q;                                                                           // 832
    };                                                                                      // 833
                                                                                            // 834
    async.priorityQueue = function (worker, concurrency) {                                  // 835
                                                                                            // 836
        function _compareTasks(a, b){                                                       // 837
          return a.priority - b.priority;                                                   // 838
        };                                                                                  // 839
                                                                                            // 840
        function _binarySearch(sequence, item, compare) {                                   // 841
          var beg = -1,                                                                     // 842
              end = sequence.length - 1;                                                    // 843
          while (beg < end) {                                                               // 844
            var mid = beg + ((end - beg + 1) >>> 1);                                        // 845
            if (compare(item, sequence[mid]) >= 0) {                                        // 846
              beg = mid;                                                                    // 847
            } else {                                                                        // 848
              end = mid - 1;                                                                // 849
            }                                                                               // 850
          }                                                                                 // 851
          return beg;                                                                       // 852
        }                                                                                   // 853
                                                                                            // 854
        function _insert(q, data, priority, callback) {                                     // 855
          if (!q.started){                                                                  // 856
            q.started = true;                                                               // 857
          }                                                                                 // 858
          if (!_isArray(data)) {                                                            // 859
              data = [data];                                                                // 860
          }                                                                                 // 861
          if(data.length == 0) {                                                            // 862
             // call drain immediately if there are no tasks                                // 863
             return async.setImmediate(function() {                                         // 864
                 if (q.drain) {                                                             // 865
                     q.drain();                                                             // 866
                 }                                                                          // 867
             });                                                                            // 868
          }                                                                                 // 869
          _each(data, function(task) {                                                      // 870
              var item = {                                                                  // 871
                  data: task,                                                               // 872
                  priority: priority,                                                       // 873
                  callback: typeof callback === 'function' ? callback : null                // 874
              };                                                                            // 875
                                                                                            // 876
              q.tasks.splice(_binarySearch(q.tasks, item, _compareTasks) + 1, 0, item);     // 877
                                                                                            // 878
              if (q.saturated && q.tasks.length === q.concurrency) {                        // 879
                  q.saturated();                                                            // 880
              }                                                                             // 881
              async.setImmediate(q.process);                                                // 882
          });                                                                               // 883
        }                                                                                   // 884
                                                                                            // 885
        // Start with a normal queue                                                        // 886
        var q = async.queue(worker, concurrency);                                           // 887
                                                                                            // 888
        // Override push to accept second parameter representing priority                   // 889
        q.push = function (data, priority, callback) {                                      // 890
          _insert(q, data, priority, callback);                                             // 891
        };                                                                                  // 892
                                                                                            // 893
        // Remove unshift function                                                          // 894
        delete q.unshift;                                                                   // 895
                                                                                            // 896
        return q;                                                                           // 897
    };                                                                                      // 898
                                                                                            // 899
    async.cargo = function (worker, payload) {                                              // 900
        var working     = false,                                                            // 901
            tasks       = [];                                                               // 902
                                                                                            // 903
        var cargo = {                                                                       // 904
            tasks: tasks,                                                                   // 905
            payload: payload,                                                               // 906
            saturated: null,                                                                // 907
            empty: null,                                                                    // 908
            drain: null,                                                                    // 909
            drained: true,                                                                  // 910
            push: function (data, callback) {                                               // 911
                if (!_isArray(data)) {                                                      // 912
                    data = [data];                                                          // 913
                }                                                                           // 914
                _each(data, function(task) {                                                // 915
                    tasks.push({                                                            // 916
                        data: task,                                                         // 917
                        callback: typeof callback === 'function' ? callback : null          // 918
                    });                                                                     // 919
                    cargo.drained = false;                                                  // 920
                    if (cargo.saturated && tasks.length === payload) {                      // 921
                        cargo.saturated();                                                  // 922
                    }                                                                       // 923
                });                                                                         // 924
                async.setImmediate(cargo.process);                                          // 925
            },                                                                              // 926
            process: function process() {                                                   // 927
                if (working) return;                                                        // 928
                if (tasks.length === 0) {                                                   // 929
                    if(cargo.drain && !cargo.drained) cargo.drain();                        // 930
                    cargo.drained = true;                                                   // 931
                    return;                                                                 // 932
                }                                                                           // 933
                                                                                            // 934
                var ts = typeof payload === 'number'                                        // 935
                            ? tasks.splice(0, payload)                                      // 936
                            : tasks.splice(0, tasks.length);                                // 937
                                                                                            // 938
                var ds = _map(ts, function (task) {                                         // 939
                    return task.data;                                                       // 940
                });                                                                         // 941
                                                                                            // 942
                if(cargo.empty) cargo.empty();                                              // 943
                working = true;                                                             // 944
                worker(ds, function () {                                                    // 945
                    working = false;                                                        // 946
                                                                                            // 947
                    var args = arguments;                                                   // 948
                    _each(ts, function (data) {                                             // 949
                        if (data.callback) {                                                // 950
                            data.callback.apply(null, args);                                // 951
                        }                                                                   // 952
                    });                                                                     // 953
                                                                                            // 954
                    process();                                                              // 955
                });                                                                         // 956
            },                                                                              // 957
            length: function () {                                                           // 958
                return tasks.length;                                                        // 959
            },                                                                              // 960
            running: function () {                                                          // 961
                return working;                                                             // 962
            }                                                                               // 963
        };                                                                                  // 964
        return cargo;                                                                       // 965
    };                                                                                      // 966
                                                                                            // 967
    var _console_fn = function (name) {                                                     // 968
        return function (fn) {                                                              // 969
            var args = Array.prototype.slice.call(arguments, 1);                            // 970
            fn.apply(null, args.concat([function (err) {                                    // 971
                var args = Array.prototype.slice.call(arguments, 1);                        // 972
                if (typeof console !== 'undefined') {                                       // 973
                    if (err) {                                                              // 974
                        if (console.error) {                                                // 975
                            console.error(err);                                             // 976
                        }                                                                   // 977
                    }                                                                       // 978
                    else if (console[name]) {                                               // 979
                        _each(args, function (x) {                                          // 980
                            console[name](x);                                               // 981
                        });                                                                 // 982
                    }                                                                       // 983
                }                                                                           // 984
            }]));                                                                           // 985
        };                                                                                  // 986
    };                                                                                      // 987
    async.log = _console_fn('log');                                                         // 988
    async.dir = _console_fn('dir');                                                         // 989
    /*async.info = _console_fn('info');                                                     // 990
    async.warn = _console_fn('warn');                                                       // 991
    async.error = _console_fn('error');*/                                                   // 992
                                                                                            // 993
    async.memoize = function (fn, hasher) {                                                 // 994
        var memo = {};                                                                      // 995
        var queues = {};                                                                    // 996
        hasher = hasher || function (x) {                                                   // 997
            return x;                                                                       // 998
        };                                                                                  // 999
        var memoized = function () {                                                        // 1000
            var args = Array.prototype.slice.call(arguments);                               // 1001
            var callback = args.pop();                                                      // 1002
            var key = hasher.apply(null, args);                                             // 1003
            if (key in memo) {                                                              // 1004
                async.nextTick(function () {                                                // 1005
                    callback.apply(null, memo[key]);                                        // 1006
                });                                                                         // 1007
            }                                                                               // 1008
            else if (key in queues) {                                                       // 1009
                queues[key].push(callback);                                                 // 1010
            }                                                                               // 1011
            else {                                                                          // 1012
                queues[key] = [callback];                                                   // 1013
                fn.apply(null, args.concat([function () {                                   // 1014
                    memo[key] = arguments;                                                  // 1015
                    var q = queues[key];                                                    // 1016
                    delete queues[key];                                                     // 1017
                    for (var i = 0, l = q.length; i < l; i++) {                             // 1018
                      q[i].apply(null, arguments);                                          // 1019
                    }                                                                       // 1020
                }]));                                                                       // 1021
            }                                                                               // 1022
        };                                                                                  // 1023
        memoized.memo = memo;                                                               // 1024
        memoized.unmemoized = fn;                                                           // 1025
        return memoized;                                                                    // 1026
    };                                                                                      // 1027
                                                                                            // 1028
    async.unmemoize = function (fn) {                                                       // 1029
      return function () {                                                                  // 1030
        return (fn.unmemoized || fn).apply(null, arguments);                                // 1031
      };                                                                                    // 1032
    };                                                                                      // 1033
                                                                                            // 1034
    async.times = function (count, iterator, callback) {                                    // 1035
        var counter = [];                                                                   // 1036
        for (var i = 0; i < count; i++) {                                                   // 1037
            counter.push(i);                                                                // 1038
        }                                                                                   // 1039
        return async.map(counter, iterator, callback);                                      // 1040
    };                                                                                      // 1041
                                                                                            // 1042
    async.timesSeries = function (count, iterator, callback) {                              // 1043
        var counter = [];                                                                   // 1044
        for (var i = 0; i < count; i++) {                                                   // 1045
            counter.push(i);                                                                // 1046
        }                                                                                   // 1047
        return async.mapSeries(counter, iterator, callback);                                // 1048
    };                                                                                      // 1049
                                                                                            // 1050
    async.seq = function (/* functions... */) {                                             // 1051
        var fns = arguments;                                                                // 1052
        return function () {                                                                // 1053
            var that = this;                                                                // 1054
            var args = Array.prototype.slice.call(arguments);                               // 1055
            var callback = args.pop();                                                      // 1056
            async.reduce(fns, args, function (newargs, fn, cb) {                            // 1057
                fn.apply(that, newargs.concat([function () {                                // 1058
                    var err = arguments[0];                                                 // 1059
                    var nextargs = Array.prototype.slice.call(arguments, 1);                // 1060
                    cb(err, nextargs);                                                      // 1061
                }]))                                                                        // 1062
            },                                                                              // 1063
            function (err, results) {                                                       // 1064
                callback.apply(that, [err].concat(results));                                // 1065
            });                                                                             // 1066
        };                                                                                  // 1067
    };                                                                                      // 1068
                                                                                            // 1069
    async.compose = function (/* functions... */) {                                         // 1070
      return async.seq.apply(null, Array.prototype.reverse.call(arguments));                // 1071
    };                                                                                      // 1072
                                                                                            // 1073
    var _applyEach = function (eachfn, fns /*args...*/) {                                   // 1074
        var go = function () {                                                              // 1075
            var that = this;                                                                // 1076
            var args = Array.prototype.slice.call(arguments);                               // 1077
            var callback = args.pop();                                                      // 1078
            return eachfn(fns, function (fn, cb) {                                          // 1079
                fn.apply(that, args.concat([cb]));                                          // 1080
            },                                                                              // 1081
            callback);                                                                      // 1082
        };                                                                                  // 1083
        if (arguments.length > 2) {                                                         // 1084
            var args = Array.prototype.slice.call(arguments, 2);                            // 1085
            return go.apply(this, args);                                                    // 1086
        }                                                                                   // 1087
        else {                                                                              // 1088
            return go;                                                                      // 1089
        }                                                                                   // 1090
    };                                                                                      // 1091
    async.applyEach = doParallel(_applyEach);                                               // 1092
    async.applyEachSeries = doSeries(_applyEach);                                           // 1093
                                                                                            // 1094
    async.forever = function (fn, callback) {                                               // 1095
        function next(err) {                                                                // 1096
            if (err) {                                                                      // 1097
                if (callback) {                                                             // 1098
                    return callback(err);                                                   // 1099
                }                                                                           // 1100
                throw err;                                                                  // 1101
            }                                                                               // 1102
            fn(next);                                                                       // 1103
        }                                                                                   // 1104
        next();                                                                             // 1105
    };                                                                                      // 1106
                                                                                            // 1107
    // Node.js                                                                              // 1108
    if (typeof module !== 'undefined' && module.exports) {                                  // 1109
        module.exports = async;                                                             // 1110
    }                                                                                       // 1111
    // AMD / RequireJS                                                                      // 1112
    else if (typeof define !== 'undefined' && define.amd) {                                 // 1113
        define([], function () {                                                            // 1114
            return async;                                                                   // 1115
        });                                                                                 // 1116
    }                                                                                       // 1117
    // included directly via <script> tag                                                   // 1118
    else {                                                                                  // 1119
        root.async = async;                                                                 // 1120
    }                                                                                       // 1121
                                                                                            // 1122
}());                                                                                       // 1123
                                                                                            // 1124
//////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// packages/peerlibrary:async/export-async.js                                               //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
async = this.async;                                                                         // 1
                                                                                            // 2
//////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peerlibrary:async'] = {
  async: async
};

})();

//# sourceMappingURL=peerlibrary_async.js.map
